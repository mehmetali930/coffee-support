// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract CoffeeProfile {
    uint256 public constant MAX_NAME_LENGTH = 64;
    uint256 public constant MAX_BIO_LENGTH = 256;
    uint256 public constant MAX_AVATAR_URL_LENGTH = 512;

    error NotAdmin();
    error InvalidAdmin();
    error NameTooLong(uint256 provided, uint256 maxAllowed);
    error BioTooLong(uint256 provided, uint256 maxAllowed);
    error AvatarUrlTooLong(uint256 provided, uint256 maxAllowed);

    struct Profile {
        string name;
        string bio;
        string avatarUrl;
    }

    struct Donation {
        string coffeeName;
        uint256 amountUsdc;
        string fraction;
        uint256 timestamp;
    }

    address public admin;

    mapping(address => Profile) private _profiles;
    mapping(address => Donation[]) private _donationHistory;
    mapping(address => uint256) private _donationCount;
    mapping(address => uint256) private _totalDonated;

    address[] private _donors;
    mapping(address => bool) private _isDonorTracked;

    Donation[] private _allDonations;
    uint256 private _totalAmountUsdc;

    event ProfileUpdated(address indexed user, string name);
    event DonationRecorded(address indexed donor, string coffeeName, uint256 amountUsdc, uint256 timestamp);
    event AdminTransferred(address indexed oldAdmin, address indexed newAdmin);

    modifier onlyAdmin() {
        if (msg.sender != admin) revert NotAdmin();
        _;
    }

    constructor(address admin_) {
        if (admin_ == address(0)) revert InvalidAdmin();
        admin = admin_;
    }

    function setProfile(string calldata name, string calldata bio, string calldata avatarUrl) external {
        if (bytes(name).length > MAX_NAME_LENGTH) {
            revert NameTooLong(bytes(name).length, MAX_NAME_LENGTH);
        }
        if (bytes(bio).length > MAX_BIO_LENGTH) {
            revert BioTooLong(bytes(bio).length, MAX_BIO_LENGTH);
        }
        if (bytes(avatarUrl).length > MAX_AVATAR_URL_LENGTH) {
            revert AvatarUrlTooLong(bytes(avatarUrl).length, MAX_AVATAR_URL_LENGTH);
        }

        _profiles[msg.sender] = Profile({name: name, bio: bio, avatarUrl: avatarUrl});

        emit ProfileUpdated(msg.sender, name);
    }

    function getProfile(address user)
        external
        view
        returns (string memory name, string memory bio, string memory avatarUrl, uint256 donationCount, uint256 totalDonated)
    {
        Profile storage profile = _profiles[user];

        return (
            profile.name,
            profile.bio,
            profile.avatarUrl,
            _donationCount[user],
            _totalDonated[user]
        );
    }

    function recordDonation(
        address donor,
        string calldata coffeeName,
        uint256 amountUsdc,
        string calldata fraction
    ) external {
        require(donor == msg.sender, "CoffeeProfile: donor must be caller");
        require(amountUsdc != 0, "CoffeeProfile: amountUsdc must be greater than zero");
        require(bytes(coffeeName).length != 0, "CoffeeProfile: coffeeName must not be empty");

        Donation memory donation = Donation({
            coffeeName: coffeeName,
            amountUsdc: amountUsdc,
            fraction: fraction,
            timestamp: block.timestamp
        });

        _donationHistory[donor].push(donation);
        _allDonations.push(donation);

        _donationCount[donor] += 1;
        _totalDonated[donor] += amountUsdc;
        _totalAmountUsdc += amountUsdc;

        if (!_isDonorTracked[donor]) {
            _isDonorTracked[donor] = true;
            _donors.push(donor);
        }

        emit DonationRecorded(donor, coffeeName, amountUsdc, donation.timestamp);
    }

    function getDonationHistory(address donor) external view returns (Donation[] memory) {
        return _donationHistory[donor];
    }

    function getDonationCount(address donor) external view returns (uint256) {
        return _donationCount[donor];
    }

    function getTotalDonated(address donor) external view returns (uint256) {
        return _totalDonated[donor];
    }

    function getAllDonors() external view onlyAdmin returns (address[] memory) {
        return _donors;
    }

    function getAllDonations() external view onlyAdmin returns (Donation[] memory) {
        return _allDonations;
    }

    function getStats() external view onlyAdmin returns (uint256 totalDonors, uint256 totalDonations, uint256 totalAmountUsdc) {
        return (_donors.length, _allDonations.length, _totalAmountUsdc);
    }

    function transferAdmin(address newAdmin) external onlyAdmin {
        if (newAdmin == address(0)) revert InvalidAdmin();
        emit AdminTransferred(admin, newAdmin);
        admin = newAdmin;
    }
}
