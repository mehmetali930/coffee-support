/**
 * Coffee Support — App Constants
 * All blockchain config comes from environment variables so switching
 * from testnet to mainnet only requires an .env change.
 */

import { getUsdc, requireChain } from '@/onchain-facts'

// ─── Chain Configuration ──────────────────────────────────────────────────────

/** The target chain ID. Override via VITE_CHAIN_ID env var. */
export const TARGET_CHAIN_ID: number = parseInt(
  String(import.meta.env.VITE_CHAIN_ID ?? '84532'),
  10,
)

export const TARGET_CHAIN = requireChain(TARGET_CHAIN_ID)

const usdcFact = getUsdc(TARGET_CHAIN_ID)
if (!usdcFact) {
  throw new Error(`USDC is not deployed on chain ${TARGET_CHAIN_ID}`)
}

/** USDC contract address on the target chain. Override via VITE_TEST_USDC_ADDRESS. */
export const USDC_ADDRESS = (
  import.meta.env.VITE_TEST_USDC_ADDRESS ?? usdcFact.address
) as `0x${string}`

/** USDC decimals on the target chain (always 6 for Circle USDC). */
export const USDC_DECIMALS = usdcFact.decimals

/**
 * Donation recipient address.
 * MUST be set in .env as VITE_RECIPIENT_ADDRESS.
 * Falls back to a placeholder that makes the UI prompt the user to configure it.
 */
export const RECIPIENT_ADDRESS = (
  import.meta.env.VITE_RECIPIENT_ADDRESS ?? ''
) as `0x${string}`

// ─── Donation Amounts (in USDC, whole units) ──────────────────────────────────

/** 1 coffee = 4 USDC */
export const ONE_COFFEE_USDC = 4

/** Half coffee = 2 USDC */
export const HALF_COFFEE_USDC = 2

/** Quarter coffee = 1 USDC */
export const QUARTER_COFFEE_USDC = 1

// ─── Donation Tiers ───────────────────────────────────────────────────────────

export interface DonationTier {
  id: string
  label: string
  fraction: string
  amount: number
  description: string
}

export const DONATION_TIERS: DonationTier[] = [
  {
    id: 'full',
    label: '1 Coffee',
    fraction: '1',
    amount: ONE_COFFEE_USDC,
    description: 'Full cup',
  },
  {
    id: 'half',
    label: '½ Coffee',
    fraction: '½',
    amount: HALF_COFFEE_USDC,
    description: 'Half cup',
  },
  {
    id: 'quarter',
    label: '¼ Coffee',
    fraction: '¼',
    amount: QUARTER_COFFEE_USDC,
    description: 'Small sip',
  },
]

// ─── Coffee Menu ──────────────────────────────────────────────────────────────

export interface CoffeeItem {
  id: string
  name: string
  size: string
  emoji: string
  /** Short flavour note shown under the name */
  note: string
}

export const COFFEES: CoffeeItem[] = [
  {
    id: 'americano',
    name: 'Americano',
    size: 'Small (Tall)',
    emoji: '☕',
    note: 'Bold espresso & hot water',
  },
  {
    id: 'latte',
    name: 'Caffè Latte',
    size: 'Small (Tall)',
    emoji: '🥛',
    note: 'Smooth espresso with steamed milk',
  },
  {
    id: 'cappuccino',
    name: 'Cappuccino',
    size: 'Small (Tall)',
    emoji: '☕',
    note: 'Rich foam over double espresso',
  },
  {
    id: 'caramel-macchiato',
    name: 'Caramel Macchiato',
    size: 'Small (Tall)',
    emoji: '🍮',
    note: 'Vanilla, milk & caramel drizzle',
  },
  {
    id: 'flat-white',
    name: 'Flat White',
    size: 'Small (Tall)',
    emoji: '☕',
    note: 'Velvety microfoam espresso',
  },
]

// ─── Section Titles ───────────────────────────────────────────────────────────

export const SECTION_TITLES: Record<string, { title: string; subtitle: string }> = {
  full: {
    title: 'Buy Me a Coffee',
    subtitle: 'Support my daily coffee habit with an onchain donation.',
  },
  half: {
    title: 'Half Coffee Support',
    subtitle: 'Even half a cup keeps the ideas brewing.',
  },
  quarter: {
    title: 'Small Coffee Support',
    subtitle: 'Every sip counts — thank you for your support.',
  },
}
