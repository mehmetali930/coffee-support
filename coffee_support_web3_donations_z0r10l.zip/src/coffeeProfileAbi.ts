export const coffeeProfileAbi = [
  {
    type: 'constructor',
    inputs: [{ name: 'admin_', type: 'address' }],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function', name: 'admin',
    inputs: [], outputs: [{ name: '', type: 'address' }],
    stateMutability: 'view',
  },
  {
    type: 'function', name: 'setProfile',
    inputs: [
      { name: 'name', type: 'string' },
      { name: 'bio', type: 'string' },
      { name: 'avatarUrl', type: 'string' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function', name: 'recordDonation',
    inputs: [
      { name: 'donor', type: 'address' },
      { name: 'coffeeName', type: 'string' },
      { name: 'amountUsdc', type: 'uint256' },
      { name: 'fraction', type: 'string' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function', name: 'getProfile',
    inputs: [{ name: 'user', type: 'address' }],
    outputs: [
      { name: 'name', type: 'string' },
      { name: 'bio', type: 'string' },
      { name: 'avatarUrl', type: 'string' },
      { name: 'donationCount', type: 'uint256' },
      { name: 'totalDonated', type: 'uint256' },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function', name: 'getDonationHistory',
    inputs: [{ name: 'donor', type: 'address' }],
    outputs: [
      {
        name: '', type: 'tuple[]',
        components: [
          { name: 'coffeeName', type: 'string' },
          { name: 'amountUsdc', type: 'uint256' },
          { name: 'fraction', type: 'string' },
          { name: 'timestamp', type: 'uint256' },
        ],
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function', name: 'getAllDonors',
    inputs: [], outputs: [{ name: '', type: 'address[]' }],
    stateMutability: 'view',
  },
  {
    type: 'function', name: 'getAllDonations',
    inputs: [],
    outputs: [
      {
        name: '', type: 'tuple[]',
        components: [
          { name: 'coffeeName', type: 'string' },
          { name: 'amountUsdc', type: 'uint256' },
          { name: 'fraction', type: 'string' },
          { name: 'timestamp', type: 'uint256' },
        ],
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function', name: 'getStats',
    inputs: [],
    outputs: [
      { name: 'totalDonors', type: 'uint256' },
      { name: 'totalDonations', type: 'uint256' },
      { name: 'totalAmountUsdc', type: 'uint256' },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function', name: 'transferAdmin',
    inputs: [{ name: 'newAdmin', type: 'address' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'event', name: 'ProfileUpdated',
    inputs: [
      { name: 'user', type: 'address', indexed: true },
      { name: 'name', type: 'string', indexed: false },
    ],
  },
  {
    type: 'event', name: 'DonationRecorded',
    inputs: [
      { name: 'donor', type: 'address', indexed: true },
      { name: 'coffeeName', type: 'string', indexed: false },
      { name: 'amountUsdc', type: 'uint256', indexed: false },
      { name: 'timestamp', type: 'uint256', indexed: false },
    ],
  },
  {
    type: 'event', name: 'AdminTransferred',
    inputs: [
      { name: 'oldAdmin', type: 'address', indexed: true },
      { name: 'newAdmin', type: 'address', indexed: true },
    ],
  },
  { type: 'error', name: 'NotAdmin', inputs: [] },
  { type: 'error', name: 'NotDonor', inputs: [] },
  { type: 'error', name: 'InvalidAdmin', inputs: [] },
  { type: 'error', name: 'NameTooLong', inputs: [] },
  { type: 'error', name: 'BioTooLong', inputs: [] },
  { type: 'error', name: 'AvatarUrlTooLong', inputs: [] },
] as const
