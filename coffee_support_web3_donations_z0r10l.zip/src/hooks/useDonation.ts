/**
 * useDonation — USDC transfer flow for coffee donations.
 *
 * The entire flow runs inside a single async function (handleConfirm) so
 * every state transition is driven by awaited results — no wagmi state sync
 * effects, no phase-guard bugs, no stale-closure issues.
 */

import { useState, useCallback } from 'react'
import { useAccount, useSwitchChain } from 'wagmi'
import { useWriteContract, usePublicClient } from 'wagmi'
import { erc20Abi } from 'viem'
import { parseAmount } from '@/onchain-money'
import {
  CoffeeItem,
  DonationTier,
  USDC_ADDRESS,
  RECIPIENT_ADDRESS,
  TARGET_CHAIN_ID,
} from '../constants'
import type { TxStatus, PendingDonation } from '../components/DonationModal'
import type { DonationRecord } from '../components/DonationHistory'

function parseOnchainError(error: unknown): string {
  const msg = (error as { message?: string })?.message ?? ''
  const lower = msg.toLowerCase()
  if (lower.includes('user rejected') || (error as { code?: number })?.code === 4001) {
    return 'cancelled'
  }
  if (lower.includes('insufficient funds') || lower.includes('exceeds balance')) {
    return 'Insufficient USDC balance. Please add funds and try again.'
  }
  if (lower.includes('reverted')) {
    const m = lower.match(/reason="([^"]+)"/)
    return m ? `Transaction failed: ${m[1]}` : 'Transaction reverted. Please try again.'
  }
  if (lower.includes('network') || lower.includes('timeout')) {
    return 'Network error. Please check your connection and retry.'
  }
  return msg.length > 120 ? msg.slice(0, 120) + '…' : msg || 'Something went wrong.'
}

export function useDonation() {
  const { address, chainId, isConnected } = useAccount()
  const { switchChainAsync } = useSwitchChain()
  const { writeContractAsync } = useWriteContract()
  const publicClient = usePublicClient({ chainId: TARGET_CHAIN_ID })

  const [pending, setPending] = useState<PendingDonation | null>(null)
  const [status, setStatus] = useState<TxStatus>('idle')
  const [txHash, setTxHash] = useState<`0x${string}` | undefined>(undefined)
  const [errorMessage, setErrorMessage] = useState<string | undefined>(undefined)
  const [history, setHistory] = useState<DonationRecord[]>([])
  /** Custom recipient override entered by the user in the modal */
  const [customRecipient, setCustomRecipient] = useState<string>('')

  // Open the modal with a chosen coffee + tier
  const openModal = useCallback((coffee: CoffeeItem, tier: DonationTier) => {
    setPending({ coffee, tier })
    setStatus('idle')
    setTxHash(undefined)
    setErrorMessage(undefined)
  }, [])

  // Close — blocked while tx is in-flight
  const closeModal = useCallback(() => {
    if (status === 'awaiting-approval' || status === 'submitted' || status === 'confirming') return
    setPending(null)
    setStatus('idle')
    setTxHash(undefined)
    setErrorMessage(undefined)
  }, [status])

  // Retry after error — go back to idle inside the modal
  const retry = useCallback(() => {
    setStatus('idle')
    setErrorMessage(undefined)
    setTxHash(undefined)
  }, [])

  // Main confirm — the entire async flow in one place
  const confirm = useCallback(async () => {
    if (!pending) return

    // Priority: custom recipient entered in modal → env var → connected wallet
    const resolvedRecipient = (
      customRecipient.trim() || RECIPIENT_ADDRESS || address
    ) as `0x${string}` | undefined
    const recipient = resolvedRecipient
    if (!recipient) return

    try {
      // 1. Switch chain if needed
      if (chainId !== TARGET_CHAIN_ID) {
        setStatus('awaiting-approval')
        await switchChainAsync({ chainId: TARGET_CHAIN_ID })
      }

      // 2. Send the USDC transfer — wallet approval prompt
      setStatus('awaiting-approval')
      const parsedAmount = parseAmount(TARGET_CHAIN_ID, pending.tier.amount.toString())

      const hash = await writeContractAsync({
        address: USDC_ADDRESS,
        abi: erc20Abi,
        functionName: 'transfer',
        args: [recipient, parsedAmount.raw],
      })

      // 3. Transaction is in the mempool
      setTxHash(hash)
      setStatus('submitted')

      // 4. Wait for confirmation
      setStatus('confirming')
      if (!publicClient) throw new Error('No public client for Base Sepolia')
      await publicClient.waitForTransactionReceipt({ hash })

      // 5. Success
      setStatus('success')
      setHistory((prev) => [
        {
          id: hash,
          coffeeName: pending.coffee.name,
          amount: pending.tier.amount,
          address: address ?? '',
          txHash: hash,
          timestamp: Date.now(),
          status: 'confirmed',
        },
        ...prev.slice(0, 19),
      ])
    } catch (err) {
      const msg = parseOnchainError(err)
      if (msg === 'cancelled') {
        // User rejected in wallet — silently go back to the confirm sheet
        setStatus('idle')
        setErrorMessage(undefined)
      } else {
        setStatus('error')
        setErrorMessage(msg)
      }
    }
  }, [pending, customRecipient, address, chainId, switchChainAsync, writeContractAsync, publicClient])

  return {
    pending,
    status,
    txHash,
    errorMessage,
    history,
    isConnected,
    openModal,
    closeModal,
    confirm,
    retry,
    customRecipient,
    setCustomRecipient,
  }
}
