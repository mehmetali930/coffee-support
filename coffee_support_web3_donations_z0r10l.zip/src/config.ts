/**
 * wagmi configuration — Coffee Support App
 * Built with Arc Studio — https://studio.arc.io
 *
 * Target: Arc Testnet (chain ID 5042002)
 * USDC is the native gas token on Arc — no separate ETH needed.
 * To switch to Arc Mainnet in the future, update VITE_CHAIN_ID=5042 in .env
 */

import { http, createConfig } from 'wagmi'
import { mainnet } from 'wagmi/chains'
import { defineChain } from 'viem'
import { injected, coinbaseWallet } from 'wagmi/connectors'
import { registerChain } from './tracing'

// Arc Testnet — USDC is the native gas token
export const arcTestnet = defineChain({
  id: 5042002,
  name: 'Arc Testnet',
  nativeCurrency: {
    name: 'USDC',
    symbol: 'USDC',
    decimals: 18,
  },
  rpcUrls: {
    default: { http: ['https://rpc.testnet.arc.io'] },
  },
  blockExplorers: {
    default: {
      name: 'Arc Explorer',
      url: 'https://explorer.testnet.arc.io',
    },
  },
  testnet: true,
})

// Pre-register chain RPC URL so trace events show correct chain names immediately
registerChain(arcTestnet.id, 'https://rpc.testnet.arc.io')

export const config = createConfig({
  chains: [arcTestnet, mainnet], // mainnet kept for ENS resolution only
  connectors: [
    injected(),                               // MetaMask + any browser-injected wallet
    coinbaseWallet({ appName: 'Coffee Support' }),
  ],
  transports: {
    [arcTestnet.id]: http('https://rpc.testnet.arc.io'),
    [mainnet.id]: http(),
  },
})
