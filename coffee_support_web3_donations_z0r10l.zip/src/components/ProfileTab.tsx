/**
 * ProfileTab — bağlı kullanıcının profil yönetimi ve bağış geçmişi.
 * Profil bilgileri (isim, bio, avatarUrl) CoffeeProfile kontratında onchain saklanır.
 */

import { useState } from 'react'
import { useAccount, useWriteContract, usePublicClient, useReadContract } from 'wagmi'

import { coffeeProfileAbi } from '../coffeeProfileAbi'
import { Loader2, CheckCircle, AlertCircle, User, Edit3, Save, X } from 'lucide-react'

const CONTRACT = import.meta.env.VITE_COFFEE_PROFILE_ADDRESS as `0x${string}`
const CHAIN_ID = 5042002 as const

const s = {
  card: { background: '#fff', borderRadius: 16, border: '1px solid rgba(44,26,14,0.10)', boxShadow: '0 2px 12px rgba(44,26,14,0.07)', padding: '20px 20px', fontFamily: 'system-ui,sans-serif' } as React.CSSProperties,
  label: { fontSize: 11, fontWeight: 600, color: '#9c7b62', textTransform: 'uppercase' as const, letterSpacing: '0.08em', display: 'block', marginBottom: 6 },
  input: { width: '100%', padding: '10px 12px', borderRadius: 10, border: '1.5px solid rgba(44,26,14,0.14)', fontSize: 13, fontFamily: 'system-ui,sans-serif', background: '#faf5f0', color: '#2c1a0e', outline: 'none', boxSizing: 'border-box' as const },
  btn: (active: boolean) => ({ padding: '11px 20px', borderRadius: 10, background: active ? '#2c1a0e' : 'rgba(44,26,14,0.08)', color: active ? '#fff' : '#9c7b62', border: 'none', fontSize: 13, fontWeight: 700, cursor: active ? 'pointer' : 'not-allowed', fontFamily: 'system-ui,sans-serif' } as React.CSSProperties),
}

type Donation = { coffeeName: string; amountUsdc: bigint; fraction: string; timestamp: bigint }

export function ProfileTab() {
  const { address, isConnected } = useAccount()
  const { writeContractAsync } = useWriteContract()
  const publicClient = usePublicClient({ chainId: CHAIN_ID })

  // Profile form state
  const [editing, setEditing] = useState(false)
  const [editName, setEditName] = useState('')
  const [editBio, setEditBio] = useState('')
  const [editAvatarUrl, setEditAvatarUrl] = useState('')
  const [saving, setSaving] = useState(false)
  const [saveMsg, setSaveMsg] = useState<{ ok: boolean; text: string } | null>(null)

  // Read profile from chain
  const { data: profileData, refetch: refetchProfile, isLoading: profileLoading } = useReadContract({
    address: CONTRACT,
    abi: coffeeProfileAbi,
    functionName: 'getProfile',
    args: address ? [address] : undefined,
    chainId: CHAIN_ID,
    query: { enabled: Boolean(address) },
  })

  // Read donation history
  const { data: historyData, refetch: refetchHistory, isLoading: historyLoading } = useReadContract({
    address: CONTRACT,
    abi: coffeeProfileAbi,
    functionName: 'getDonationHistory',
    args: address ? [address] : undefined,
    chainId: CHAIN_ID,
    query: { enabled: Boolean(address) },
  })

  const handleSaveProfile = async () => {
    if (!address || !publicClient) return
    setSaving(true)
    setSaveMsg(null)
    try {
      const hash = await writeContractAsync({
        address: CONTRACT,
        abi: coffeeProfileAbi,
        functionName: 'setProfile',
        args: [editName.slice(0, 64), editBio.slice(0, 256), editAvatarUrl.slice(0, 512)],
      })
      await publicClient.waitForTransactionReceipt({ hash })
      setSaveMsg({ ok: true, text: 'Profil güncellendi!' })
      setEditing(false)
      void refetchProfile()
    } catch (e) {
      const msg = ((e as { message?: string }).message ?? '').toLowerCase()
      if (!msg.includes('user rejected')) {
        setSaveMsg({ ok: false, text: 'Güncelleme başarısız. Tekrar dene.' })
      }
    } finally {
      setSaving(false)
    }
  }

  const donations = (historyData as Donation[] | undefined) ?? []
  const profile = profileData as [string, string, string, bigint, bigint] | undefined
  const displayName = profile?.[0] || ''
  const displayBio = profile?.[1] || ''
  const displayAvatarUrl = profile?.[2] || ''
  const totalDonated = profile?.[4] ?? 0n

  const fmt = (a: string) => `${a.slice(0, 6)}…${a.slice(-4)}`
  const fmtDate = (ts: bigint) => new Date(Number(ts) * 1000).toLocaleDateString('tr-TR', { day: '2-digit', month: 'short', year: 'numeric' })

  if (!isConnected) {
    return (
      <div style={{ textAlign: 'center', padding: '48px 16px', fontFamily: 'system-ui,sans-serif' }}>
        <div style={{ fontSize: 40, marginBottom: 12 }}>👤</div>
        <p style={{ fontSize: 16, fontWeight: 700, color: '#2c1a0e', margin: '0 0 6px' }}>Profil görüntülemek için cüzdanını bağla</p>
        <p style={{ fontSize: 13, color: '#9c7b62', margin: 0 }}>Cüzdanını bağladıktan sonra profilini düzenleyebilir ve bağış geçmişini görebilirsin.</p>
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 640, margin: '0 auto' }}>

      {/* Profile Card */}
      <div style={s.card}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <p style={{ fontSize: 14, fontWeight: 700, color: '#2c1a0e', margin: 0 }}>Profilim</p>
          {!editing && (
            <button onClick={() => { setEditName(displayName); setEditBio(displayBio); setEditAvatarUrl(displayAvatarUrl); setEditing(true) }}
              style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 12px', borderRadius: 8, background: 'rgba(44,26,14,0.06)', border: '1px solid rgba(44,26,14,0.10)', fontSize: 12, fontWeight: 600, color: '#4a2c1a', cursor: 'pointer' }}>
              <Edit3 size={12} /> Düzenle
            </button>
          )}
        </div>

        {/* Avatar + address row */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16, background: '#faf5f0', borderRadius: 12, padding: '12px 14px' }}>
          <div style={{ width: 52, height: 52, borderRadius: '50%', background: 'linear-gradient(135deg,#f5d9a8,#d4884a)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, overflow: 'hidden' }}>
            {displayAvatarUrl && !editing ? (
              <img src={displayAvatarUrl} alt="avatar" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: '50%' }} onError={e => { (e.currentTarget).style.display = 'none' }} />
            ) : (
              <User size={24} style={{ color: '#7a4010' }} />
            )}
          </div>
          <div style={{ minWidth: 0 }}>
            <p style={{ fontSize: 14, fontWeight: 700, color: '#2c1a0e', margin: '0 0 2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {profileLoading ? '…' : (displayName || 'İsimsiz')}
            </p>
            <p style={{ fontSize: 11, fontFamily: 'monospace', color: '#9c7b62', margin: '0 0 2px' }}>{fmt(address!)}</p>
            {displayBio && !editing && (
              <p style={{ fontSize: 12, color: '#7a5c44', margin: 0, lineHeight: 1.5 }}>{displayBio.toString()}</p>
            )}
          </div>
        </div>

        {/* Stats row */}
        <div style={{ display: 'flex', gap: 8, marginBottom: editing ? 16 : 0 }}>
          <div style={{ flex: 1, background: 'rgba(44,26,14,0.04)', borderRadius: 10, padding: '10px 12px', textAlign: 'center' }}>
            <p style={{ fontSize: 18, fontWeight: 800, color: '#2c1a0e', margin: '0 0 2px' }}>{donations.length}</p>
            <p style={{ fontSize: 10, fontWeight: 600, color: '#9c7b62', margin: 0, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Bağış</p>
          </div>
          <div style={{ flex: 1, background: 'rgba(44,26,14,0.04)', borderRadius: 10, padding: '10px 12px', textAlign: 'center' }}>
            <p style={{ fontSize: 18, fontWeight: 800, color: '#2c1a0e', margin: '0 0 2px' }}>{totalDonated.toString()} <span style={{ fontSize: 11, fontWeight: 600 }}>USDC</span></p>
            <p style={{ fontSize: 10, fontWeight: 600, color: '#9c7b62', margin: 0, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Toplam</p>
          </div>
        </div>

        {/* Edit form */}
        {editing && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div>
              <label style={s.label}>İsim (maks. 64 karakter)</label>
              <input value={editName} onChange={e => setEditName(e.target.value)} maxLength={64} placeholder="Görünen adın" style={s.input} />
            </div>
            <div>
              <label style={s.label}>Bio (maks. 256 karakter)</label>
              <textarea value={editBio} onChange={e => setEditBio(e.target.value)} maxLength={256} placeholder="Kendinden kısaca bahset…" rows={3}
                style={{ ...s.input, resize: 'vertical', lineHeight: 1.5 }} />
            </div>
            <div>
              <label style={s.label}>Avatar URL (resim linki)</label>
              <input value={editAvatarUrl} onChange={e => setEditAvatarUrl(e.target.value)} maxLength={512} placeholder="https://…" style={s.input} />
              <p style={{ fontSize: 11, color: '#9c7b62', margin: '4px 0 0' }}>IPFS veya herhangi bir resim URL'si. Örn: https://i.imgur.com/abc.jpg</p>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={() => { void handleSaveProfile() }} disabled={saving}
                style={{ ...s.btn(!saving), flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                {saving ? 'Kaydediliyor…' : 'Kaydet'}
              </button>
              <button onClick={() => { setEditing(false); setSaveMsg(null) }}
                style={{ padding: '11px 14px', borderRadius: 10, background: '#faf5f0', border: '1px solid rgba(44,26,14,0.10)', cursor: 'pointer', color: '#7a5c44', display: 'flex', alignItems: 'center' }}>
                <X size={14} />
              </button>
            </div>
            {saveMsg && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px', borderRadius: 8, background: saveMsg.ok ? 'rgba(26,128,71,0.08)' : 'rgba(186,43,76,0.08)', border: `1px solid ${saveMsg.ok ? 'rgba(26,128,71,0.20)' : 'rgba(186,43,76,0.20)'}` }}>
                {saveMsg.ok ? <CheckCircle size={14} style={{ color: '#1a8047' }} /> : <AlertCircle size={14} style={{ color: '#ba2b4c' }} />}
                <p style={{ fontSize: 12, margin: 0, color: saveMsg.ok ? '#1a8047' : '#ba2b4c' }}>{saveMsg.text}</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Donation History */}
      <div style={s.card}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <p style={{ fontSize: 14, fontWeight: 700, color: '#2c1a0e', margin: 0 }}>Bağış Geçmişim</p>
          <button onClick={() => { void refetchHistory() }} style={{ fontSize: 11, color: '#9c7b62', background: 'none', border: 'none', cursor: 'pointer', textDecoration: 'underline' }}>Yenile</button>
        </div>

        {historyLoading ? (
          <div style={{ textAlign: 'center', padding: '24px 0' }}>
            <Loader2 size={20} className="animate-spin" style={{ color: '#c49a6c' }} />
          </div>
        ) : donations.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '24px 0', color: '#9c7b62' }}>
            <p style={{ fontSize: 28, margin: '0 0 8px' }}>☕</p>
            <p style={{ fontSize: 13, margin: 0 }}>Henüz bağış kaydın yok. İlk kahveyi gönder!</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[...donations].reverse().map((d, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#faf5f0', borderRadius: 12, padding: '10px 14px' }}>
                <div>
                  <p style={{ fontSize: 13, fontWeight: 700, color: '#2c1a0e', margin: '0 0 2px' }}>☕ {d.coffeeName}</p>
                  <p style={{ fontSize: 11, color: '#9c7b62', margin: 0 }}>{d.fraction} coffee · {fmtDate(d.timestamp)}</p>
                </div>
                <p style={{ fontSize: 14, fontWeight: 800, color: '#2c1a0e', margin: 0 }}>{d.amountUsdc.toString()} <span style={{ fontSize: 11, fontWeight: 600, color: '#7a5c44' }}>USDC</span></p>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  )
}
