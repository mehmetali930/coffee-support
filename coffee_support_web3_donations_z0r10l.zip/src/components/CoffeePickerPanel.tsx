/**
 * CoffeePickerPanel
 * ─────────────────
 * Step 1 — Pick a coffee (5 cards, horizontal scroll on mobile)
 * Step 2 — Pick size: Full / Half / Quarter  +  live amount
 * Step 3 — Donate button fires onDonate(coffee, tier)
 */

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { COFFEES, DONATION_TIERS, CoffeeItem, DonationTier } from '../constants'

// ── SVG illustrations (unique per coffee) ─────────────────────────────────────

function CoffeeIllustration({ id, size = 56 }: { id: string; size?: number }) {
  if (id === 'latte') {
    return (
      <svg width={size} height={size} viewBox="0 0 56 56" fill="none">
        {/* Tall glass */}
        <rect x="14" y="10" width="28" height="36" rx="5" fill="rgba(210,175,120,0.30)" />
        {/* Milk layer */}
        <rect x="14" y="28" width="28" height="18" rx="4" fill="rgba(240,220,180,0.55)" />
        {/* Espresso layer */}
        <rect x="14" y="10" width="28" height="12" rx="4" fill="rgba(90,45,10,0.45)" />
        {/* Foam top */}
        <ellipse cx="28" cy="10" rx="14" ry="4" fill="rgba(245,235,210,0.80)" />
        {/* Latte art swirl */}
        <path d="M22 12 Q28 8 34 12" stroke="rgba(160,100,40,0.55)" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
        {/* Handle */}
        <path d="M42 20 Q50 18 48 30 Q46 38 42 36" stroke="rgba(140,90,40,0.45)" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
        {/* Shadow */}
        <ellipse cx="28" cy="48" rx="12" ry="3" fill="rgba(90,45,10,0.10)"/>
      </svg>
    )
  }
  if (id === 'cappuccino') {
    return (
      <svg width={size} height={size} viewBox="0 0 56 56" fill="none">
        {/* Cup body */}
        <path d="M14 22 L16 44 Q16 47 20 47 H36 Q40 47 40 44 L42 22 Z" fill="rgba(200,160,100,0.30)" />
        <path d="M14 22 L16 44 Q16 47 20 47 H36 Q40 47 40 44 L42 22 Z" stroke="rgba(140,90,40,0.20)" strokeWidth="1" fill="none"/>
        {/* Rim */}
        <ellipse cx="28" cy="22" rx="14" ry="5" fill="rgba(220,190,140,0.55)"/>
        {/* Thick foam dome */}
        <ellipse cx="28" cy="20" rx="12" ry="6" fill="rgba(245,235,210,0.90)"/>
        {/* Foam swirl */}
        <path d="M22 19 Q28 15 34 19" stroke="rgba(180,130,60,0.50)" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
        <circle cx="28" cy="20" r="3" fill="rgba(160,100,40,0.20)"/>
        {/* Handle */}
        <path d="M42 28 Q50 24 48 34 Q46 40 42 38" stroke="rgba(140,90,40,0.40)" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
        {/* Shadow */}
        <ellipse cx="28" cy="50" rx="12" ry="3" fill="rgba(90,45,10,0.10)"/>
      </svg>
    )
  }
  if (id === 'caramel-macchiato') {
    return (
      <svg width={size} height={size} viewBox="0 0 56 56" fill="none">
        {/* Tall cup */}
        <rect x="13" y="12" width="30" height="34" rx="5" fill="rgba(210,160,50,0.22)"/>
        {/* Vanilla milk bottom */}
        <rect x="13" y="30" width="30" height="16" rx="4" fill="rgba(245,220,160,0.60)"/>
        {/* Espresso shot */}
        <rect x="13" y="12" width="30" height="10" rx="4" fill="rgba(80,35,5,0.50)"/>
        {/* Caramel drizzle */}
        <path d="M18 14 Q22 10 28 14 Q32 10 38 14" stroke="rgba(200,120,10,0.80)" strokeWidth="2" fill="none" strokeLinecap="round"/>
        <path d="M20 18 Q28 14 36 18" stroke="rgba(200,120,10,0.50)" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
        {/* Handle */}
        <path d="M43 22 Q51 20 49 32 Q47 40 43 38" stroke="rgba(160,100,20,0.45)" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
        {/* Shadow */}
        <ellipse cx="28" cy="48" rx="13" ry="3" fill="rgba(90,45,10,0.10)"/>
      </svg>
    )
  }
  if (id === 'flat-white') {
    return (
      <svg width={size} height={size} viewBox="0 0 56 56" fill="none">
        {/* Small wide cup */}
        <path d="M12 24 L15 44 Q15 47 19 47 H37 Q41 47 41 44 L44 24 Z" fill="rgba(200,170,120,0.28)"/>
        <path d="M12 24 L15 44 Q15 47 19 47 H37 Q41 47 41 44 L44 24 Z" stroke="rgba(140,90,40,0.18)" strokeWidth="1" fill="none"/>
        {/* Wide rim */}
        <ellipse cx="28" cy="24" rx="16" ry="5.5" fill="rgba(235,215,175,0.65)"/>
        {/* Microfoam flat surface */}
        <ellipse cx="28" cy="23" rx="14" ry="4.5" fill="rgba(248,240,220,0.92)"/>
        {/* Latte art rosette */}
        <path d="M22 22 Q25 18 28 22 Q31 18 34 22" stroke="rgba(160,100,40,0.45)" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
        <path d="M24 24 Q28 20 32 24" stroke="rgba(160,100,40,0.30)" strokeWidth="1" fill="none" strokeLinecap="round"/>
        {/* Handle */}
        <path d="M44 30 Q52 26 50 36 Q48 43 44 41" stroke="rgba(140,90,40,0.40)" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
        {/* Shadow */}
        <ellipse cx="28" cy="50" rx="13" ry="3" fill="rgba(90,45,10,0.10)"/>
      </svg>
    )
  }
  // Americano — default dark espresso
  return (
    <svg width={size} height={size} viewBox="0 0 56 56" fill="none">
      {/* Cup body */}
      <path d="M14 22 L17 44 Q17 47 21 47 H35 Q39 47 39 44 L42 22 Z" fill="rgba(60,25,5,0.22)"/>
      {/* Rim */}
      <ellipse cx="28" cy="22" rx="14" ry="5" fill="rgba(160,110,60,0.55)"/>
      {/* Dark espresso surface */}
      <ellipse cx="28" cy="24" rx="11" ry="3.5" fill="rgba(50,20,3,0.60)"/>
      {/* Crema ring */}
      <ellipse cx="28" cy="24" rx="11" ry="3.5" fill="none" stroke="rgba(180,120,40,0.40)" strokeWidth="1.5"/>
      {/* Handle */}
      <path d="M42 28 Q50 24 48 34 Q46 40 42 38" stroke="rgba(60,25,5,0.40)" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
      {/* Steam */}
      <path d="M23 17 Q24 13 22 11" stroke="rgba(60,25,5,0.22)" strokeWidth="1.5" strokeLinecap="round" fill="none"/>
      <path d="M28 15 Q29 11 27 9"  stroke="rgba(60,25,5,0.18)" strokeWidth="1.5" strokeLinecap="round" fill="none"/>
      <path d="M33 17 Q34 13 32 11" stroke="rgba(60,25,5,0.22)" strokeWidth="1.5" strokeLinecap="round" fill="none"/>
      {/* Shadow */}
      <ellipse cx="28" cy="50" rx="12" ry="3" fill="rgba(90,45,10,0.10)"/>
    </svg>
  )
}

// ── Card accent colours ────────────────────────────────────────────────────────

const CARD_BG: Record<string, string> = {
  americano:           'rgba(60,25,5,0.06)',
  latte:               'rgba(200,155,80,0.07)',
  cappuccino:          'rgba(160,100,40,0.06)',
  'caramel-macchiato': 'rgba(200,130,10,0.07)',
  'flat-white':        'rgba(120,80,30,0.05)',
}

// ── Tier pill colours ─────────────────────────────────────────────────────────

const TIER_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  full:    { bg: 'rgba(44,26,14,0.10)', text: 'var(--accent)',   border: 'rgba(44,26,14,0.18)' },
  half:    { bg: 'rgba(44,26,14,0.06)', text: 'var(--ink-2)',    border: 'rgba(44,26,14,0.12)' },
  quarter: { bg: 'rgba(44,26,14,0.04)', text: 'var(--muted)',    border: 'rgba(44,26,14,0.08)' },
}

// ── Sub-component: single coffee card ────────────────────────────────────────

function CoffeeCard({
  coffee,
  selected,
  onSelect,
}: {
  coffee: CoffeeItem
  selected: boolean
  onSelect: () => void
}) {
  return (
    <motion.button
      onClick={onSelect}
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.97 }}
      transition={{ type: 'spring', stiffness: 340, damping: 24 }}
      className="relative flex flex-col items-center gap-2.5 rounded-2xl p-4 text-center transition-shadow"
      style={{
        background: selected
          ? (CARD_BG[coffee.id] ?? 'rgba(44,26,14,0.06)')
          : 'rgba(255,255,255,0.72)',
        backdropFilter: 'blur(18px) saturate(160%)',
        WebkitBackdropFilter: 'blur(18px) saturate(160%)',
        border: selected
          ? '2px solid rgba(44,26,14,0.30)'
          : '1.5px solid rgba(255,255,255,0.72)',
        boxShadow: selected
          ? '0 6px 28px rgba(44,26,14,0.14), inset 0 1px 0 rgba(255,255,255,0.70)'
          : '0 2px 12px rgba(44,26,14,0.06), inset 0 1px 0 rgba(255,255,255,0.55)',
        minWidth: 0,
        flex: '1 1 0',
      }}
    >
      {/* Selected ring */}
      {selected && (
        <motion.div
          layoutId="coffee-ring"
          className="absolute inset-0 rounded-2xl pointer-events-none"
          style={{ border: '2px solid rgba(44,26,14,0.28)' }}
          transition={{ type: 'spring', stiffness: 400, damping: 28 }}
        />
      )}

      {/* Illustration bubble */}
      <div
        className="flex items-center justify-center rounded-xl"
        style={{
          width: 68, height: 68,
          background: selected ? 'rgba(255,255,255,0.85)' : 'rgba(255,255,255,0.60)',
          border: '1px solid rgba(255,255,255,0.80)',
          boxShadow: '0 2px 8px rgba(44,26,14,0.08)',
        }}
      >
        <CoffeeIllustration id={coffee.id} size={52} />
      </div>

      {/* Name + note */}
      <div className="w-full">
        <p
          className="display text-sm font-bold leading-tight"
          style={{ color: 'var(--ink)' }}
        >
          {coffee.name}
        </p>
        <p
          className="mt-0.5 text-xs leading-tight"
          style={{ color: 'var(--subtle)' }}
        >
          {coffee.note}
        </p>
      </div>
    </motion.button>
  )
}

// ── Sub-component: size/tier selector + amount + donate ──────────────────────

function TierSelector({
  coffee,
  onDonate,
  disabled,
}: {
  coffee: CoffeeItem
  onDonate: (coffee: CoffeeItem, tier: DonationTier) => void
  disabled: boolean
}) {
  const [selectedTierId, setSelectedTierId] = useState<string>(DONATION_TIERS[0].id)
  const tier = DONATION_TIERS.find((t) => t.id === selectedTierId) ?? DONATION_TIERS[0]

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 8 }}
      transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
      className="overflow-hidden rounded-2xl"
      style={{
        background: 'rgba(255,255,255,0.82)',
        backdropFilter: 'blur(20px) saturate(160%)',
        WebkitBackdropFilter: 'blur(20px) saturate(160%)',
        border: '1px solid rgba(255,255,255,0.72)',
        boxShadow: '0 6px 28px rgba(44,26,14,0.09), inset 0 1px 0 rgba(255,255,255,0.70)',
      }}
    >
      {/* Spectral top strip */}
      <div style={{ height: 3, background: 'linear-gradient(90deg, #5fbeff, #af8ff4, #f05c6b, #ffcd83, #7ef1b3)' }} />

      <div className="px-5 py-5 space-y-5">

        {/* Header */}
        <div className="flex items-center gap-3">
          <div
            className="flex items-center justify-center rounded-xl"
            style={{ width: 44, height: 44, background: 'rgba(44,26,14,0.05)', border: '1px solid rgba(44,26,14,0.08)' }}
          >
            <CoffeeIllustration id={coffee.id} size={34} />
          </div>
          <div>
            <p className="display text-base font-bold" style={{ color: 'var(--ink)' }}>
              {coffee.name}
            </p>
            <p className="text-xs" style={{ color: 'var(--subtle)' }}>{coffee.note}</p>
          </div>
        </div>

        {/* Tier pills */}
        <div>
          <p className="mb-2 text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)' }}>
            Choose size
          </p>
          <div className="grid grid-cols-3 gap-2">
            {DONATION_TIERS.map((t) => {
              const c = TIER_COLORS[t.id]
              const active = t.id === selectedTierId
              return (
                <motion.button
                  key={t.id}
                  onClick={() => setSelectedTierId(t.id)}
                  whileTap={{ scale: 0.96 }}
                  className="flex flex-col items-center gap-0.5 rounded-xl px-2 py-3 transition-all"
                  style={{
                    background: active ? c.bg : 'rgba(44,26,14,0.03)',
                    border: active ? `1.5px solid ${c.border}` : '1.5px solid rgba(44,26,14,0.07)',
                    boxShadow: active ? '0 2px 8px rgba(44,26,14,0.10)' : 'none',
                  }}
                >
                  <span className="display text-sm font-bold tabular-nums" style={{ color: active ? c.text : 'var(--muted)' }}>
                    {t.fraction}
                  </span>
                  <span className="text-xs font-medium" style={{ color: active ? c.text : 'var(--subtle)' }}>
                    {t.id === 'full' ? 'Full' : t.id === 'half' ? 'Half' : 'Quarter'}
                  </span>
                </motion.button>
              )
            })}
          </div>
        </div>

        {/* Amount display */}
        <AnimatePresence mode="wait">
          <motion.div
            key={tier.id}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.18 }}
            className="flex items-center justify-between rounded-xl px-4 py-3"
            style={{
              background: 'rgba(44,26,14,0.05)',
              border: '1px solid rgba(44,26,14,0.09)',
            }}
          >
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)' }}>
                Amount
              </p>
              <p className="display text-2xl font-bold tabular-nums leading-none mt-0.5" style={{ color: 'var(--accent)' }}>
                {tier.amount} USDC
              </p>
              <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>
                {tier.fraction} {coffee.name} · Test USDC
              </p>
            </div>
            <div
              className="flex flex-col items-center justify-center rounded-xl"
              style={{
                width: 52, height: 52,
                background: 'rgba(44,26,14,0.06)',
                border: '1px solid rgba(44,26,14,0.09)',
              }}
            >
              <CoffeeIllustration id={coffee.id} size={36} />
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Donate button */}
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => onDonate(coffee, tier)}
          disabled={disabled}
          className="w-full rounded-xl py-3.5 text-sm font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed"
          style={{
            background: disabled ? 'rgba(44,26,14,0.12)' : 'var(--accent)',
            color: disabled ? 'var(--muted)' : '#fff',
            boxShadow: disabled ? 'none' : '0 3px 12px rgba(44,26,14,0.28)',
            letterSpacing: '0.01em',
          }}
        >
          {disabled ? 'Connect wallet to donate' : `Donate ${tier.amount} USDC`}
        </motion.button>
      </div>
    </motion.div>
  )
}

// ── Main exported panel ───────────────────────────────────────────────────────

interface CoffeePickerPanelProps {
  onDonate: (coffee: CoffeeItem, tier: DonationTier) => void
  walletConnected: boolean
}

export function CoffeePickerPanel({ onDonate, walletConnected }: CoffeePickerPanelProps) {
  const [selectedCoffeeId, setSelectedCoffeeId] = useState<string>(COFFEES[0].id)
  const selectedCoffee = COFFEES.find((c) => c.id === selectedCoffeeId) ?? COFFEES[0]

  return (
    <div className="space-y-5">
      {/* ── Coffee selector row ── */}
      <div>
        <p className="mb-3 text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)' }}>
          Pick a coffee
        </p>
        <div className="grid gap-2.5" style={{ gridTemplateColumns: 'repeat(5, 1fr)' }}>
          {COFFEES.map((coffee) => (
            <CoffeeCard
              key={coffee.id}
              coffee={coffee}
              selected={selectedCoffeeId === coffee.id}
              onSelect={() => setSelectedCoffeeId(coffee.id)}
            />
          ))}
        </div>
      </div>

      {/* ── Tier + amount + donate ── */}
      <AnimatePresence mode="wait">
        <TierSelector
          key={selectedCoffeeId}
          coffee={selectedCoffee}
          onDonate={onDonate}
          disabled={!walletConnected}
        />
      </AnimatePresence>
    </div>
  )
}
