import { motion } from 'framer-motion'
import { CoffeeItem, DonationTier } from '../constants'

interface CoffeeCardProps {
  coffee: CoffeeItem
  tier: DonationTier
  onDonate: (coffee: CoffeeItem, tier: DonationTier) => void
  disabled?: boolean
}

// Per-coffee warm accent tint for the illustration bubble
const BUBBLE_BG: Record<string, string> = {
  americano:           'rgba(62,32,8,0.09)',
  latte:               'rgba(193,140,80,0.13)',
  cappuccino:          'rgba(160,90,30,0.11)',
  'caramel-macchiato': 'rgba(210,140,20,0.12)',
  'flat-white':        'rgba(120,70,25,0.09)',
}

// Rich SVG illustrations — distinct per coffee
function CoffeeIllustration({ id }: { id: string }) {
  switch (id) {
    case 'americano':
      return (
        <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
          {/* Dark espresso cup */}
          <ellipse cx="26" cy="42" rx="14" ry="4" fill="rgba(40,20,5,0.12)" />
          <path d="M13 20 L15 40 Q15 43 19 43 H33 Q37 43 37 40 L39 20 Z"
            fill="rgba(35,15,5,0.82)" />
          <ellipse cx="26" cy="20" rx="13" ry="4.5" fill="rgba(80,40,10,0.9)" />
          <ellipse cx="26" cy="21" rx="10" ry="3" fill="rgba(180,100,30,0.55)" />
          <path d="M39 26 Q44 22 42 32 Q40 37 37 35"
            stroke="rgba(35,15,5,0.55)" strokeWidth="3" strokeLinecap="round" fill="none" />
          {/* Steam */}
          <path d="M21 16 Q22 12 20 10" stroke="rgba(180,140,100,0.45)" strokeWidth="1.5" strokeLinecap="round" fill="none"/>
          <path d="M26 14 Q27 10 25 8"  stroke="rgba(180,140,100,0.35)" strokeWidth="1.5" strokeLinecap="round" fill="none"/>
          <path d="M31 16 Q32 12 30 10" stroke="rgba(180,140,100,0.45)" strokeWidth="1.5" strokeLinecap="round" fill="none"/>
        </svg>
      )
    case 'latte':
      return (
        <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
          {/* Tall glass */}
          <ellipse cx="26" cy="44" rx="12" ry="3.5" fill="rgba(193,140,80,0.18)" />
          <path d="M14 16 L16 42 Q16 45 20 45 H32 Q36 45 36 42 L38 16 Z"
            fill="rgba(255,235,200,0.55)" stroke="rgba(193,140,80,0.35)" strokeWidth="1" />
          {/* Milk layers */}
          <rect x="16" y="30" width="20" height="13" rx="1"
            fill="rgba(255,245,225,0.8)" />
          <rect x="16" y="22" width="20" height="10"
            fill="rgba(193,140,80,0.55)" />
          {/* Foam top */}
          <ellipse cx="26" cy="16" rx="12" ry="4" fill="rgba(255,245,225,0.9)" stroke="rgba(193,140,80,0.25)" strokeWidth="0.8" />
          <ellipse cx="22" cy="16" rx="3" ry="2" fill="rgba(255,255,255,0.7)" />
          <ellipse cx="30" cy="15.5" rx="2.5" ry="1.8" fill="rgba(255,255,255,0.6)" />
        </svg>
      )
    case 'cappuccino':
      return (
        <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
          {/* Wide cup */}
          <ellipse cx="26" cy="43" rx="15" ry="4" fill="rgba(140,80,30,0.12)" />
          <path d="M12 22 L15 41 Q15 44 19 44 H33 Q37 44 37 41 L40 22 Z"
            fill="rgba(255,250,245,0.75)" stroke="rgba(140,80,30,0.20)" strokeWidth="1" />
          {/* Coffee base */}
          <ellipse cx="26" cy="36" rx="10" ry="3" fill="rgba(100,50,10,0.45)" />
          {/* Thick foam */}
          <ellipse cx="26" cy="22" rx="14" ry="5" fill="rgba(255,245,228,0.95)" stroke="rgba(193,140,80,0.30)" strokeWidth="0.8" />
          {/* Foam art swirl */}
          <path d="M20 22 Q26 18 32 22 Q28 26 22 24" stroke="rgba(160,100,40,0.40)" strokeWidth="1.2" fill="none" strokeLinecap="round"/>
          {/* Handle */}
          <path d="M40 28 Q46 24 44 34 Q42 40 38 38"
            stroke="rgba(140,80,30,0.45)" strokeWidth="2.5" strokeLinecap="round" fill="none" />
        </svg>
      )
    case 'caramel-macchiato':
      return (
        <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
          {/* Cup */}
          <ellipse cx="26" cy="43" rx="13" ry="4" fill="rgba(200,130,20,0.15)" />
          <path d="M13 20 L15 41 Q15 44 19 44 H33 Q37 44 37 41 L39 20 Z"
            fill="rgba(255,248,230,0.80)" stroke="rgba(200,130,20,0.25)" strokeWidth="1" />
          {/* Milk */}
          <rect x="16" y="28" width="21" height="14" rx="1" fill="rgba(255,245,215,0.85)" />
          {/* Espresso shot layer */}
          <rect x="16" y="21" width="21" height="8" fill="rgba(120,60,10,0.55)" />
          {/* Caramel drizzle */}
          <path d="M18 20 Q26 14 34 20" stroke="rgba(200,130,20,0.85)" strokeWidth="2" fill="none" strokeLinecap="round"/>
          <path d="M21 20 Q26 17 31 20" stroke="rgba(230,160,40,0.70)" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
          {/* Handle */}
          <path d="M39 26 Q44 22 42 32 Q40 37 37 35"
            stroke="rgba(180,110,10,0.45)" strokeWidth="2.5" strokeLinecap="round" fill="none" />
        </svg>
      )
    default: // flat-white
      return (
        <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
          {/* Small tulip cup */}
          <ellipse cx="26" cy="43" rx="12" ry="3.5" fill="rgba(100,55,15,0.12)" />
          <path d="M15 22 L17 41 Q17 44 21 44 H31 Q35 44 35 41 L37 22 Z"
            fill="rgba(255,250,243,0.80)" stroke="rgba(100,55,15,0.18)" strokeWidth="1" />
          {/* Coffee */}
          <ellipse cx="26" cy="30" rx="9" ry="3" fill="rgba(80,40,10,0.50)" />
          {/* Microfoam top */}
          <ellipse cx="26" cy="22" rx="11" ry="4" fill="rgba(255,248,238,0.95)" stroke="rgba(160,110,60,0.25)" strokeWidth="0.8" />
          {/* Latte art: tulip */}
          <path d="M22 22 Q26 19 30 22" stroke="rgba(130,75,20,0.45)" strokeWidth="1" fill="none" strokeLinecap="round"/>
          <path d="M23 23.5 Q26 21 29 23.5" stroke="rgba(130,75,20,0.35)" strokeWidth="1" fill="none" strokeLinecap="round"/>
          {/* Handle */}
          <path d="M37 27 Q42 23 40 32 Q38 37 35 35"
            stroke="rgba(100,55,15,0.40)" strokeWidth="2.5" strokeLinecap="round" fill="none" />
        </svg>
      )
  }
}

export function CoffeeCard({ coffee, tier, onDonate, disabled }: CoffeeCardProps) {
  return (
    <motion.div
      whileHover={{ y: -4, boxShadow: '0 16px 48px rgba(44,26,14,0.13)' }}
      whileTap={{ scale: 0.975 }}
      transition={{ type: 'spring', stiffness: 320, damping: 24 }}
      className="flex flex-col items-center gap-3 rounded-2xl p-4 text-center"
      style={{
        background: 'rgba(255,255,255,0.78)',
        backdropFilter: 'blur(24px) saturate(170%)',
        WebkitBackdropFilter: 'blur(24px) saturate(170%)',
        border: '1px solid rgba(255,255,255,0.72)',
        boxShadow: '0 4px 24px rgba(44,26,14,0.07), inset 0 1px 0 rgba(255,255,255,0.65)',
      }}
    >
      {/* Coffee illustration bubble */}
      <div
        className="flex h-16 w-16 items-center justify-center rounded-2xl"
        style={{
          background: BUBBLE_BG[coffee.id] ?? 'rgba(44,26,14,0.07)',
          border: '1px solid rgba(255,255,255,0.6)',
        }}
      >
        <CoffeeIllustration id={coffee.id} />
      </div>

      {/* Coffee name */}
      <div className="flex-1">
        <p className="display text-sm font-bold leading-snug" style={{ color: 'var(--ink)' }}>
          {coffee.name}
        </p>
        <p className="mt-0.5 text-xs" style={{ color: 'var(--subtle)' }}>
          {coffee.size}
        </p>
      </div>

      {/* Price badge */}
      <div
        className="rounded-full px-3 py-1 text-sm font-bold tabular-nums"
        style={{
          background: 'rgba(44,26,14,0.07)',
          color: 'var(--accent)',
          border: '1px solid rgba(44,26,14,0.08)',
        }}
      >
        {tier.amount} USDC
      </div>

      {/* Donate button */}
      <motion.button
        whileTap={{ scale: 0.94 }}
        onClick={() => onDonate(coffee, tier)}
        disabled={disabled}
        className="w-full rounded-xl py-2.5 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-40"
        style={{
          background: disabled ? 'rgba(44,26,14,0.10)' : 'var(--accent)',
          color: disabled ? 'var(--muted)' : '#fff',
          boxShadow: disabled ? 'none' : '0 2px 10px rgba(44,26,14,0.28)',
        }}
      >
        Donate
      </motion.button>
    </motion.div>
  )
}
