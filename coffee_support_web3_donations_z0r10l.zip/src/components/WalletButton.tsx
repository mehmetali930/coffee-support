import { ConnectKitButton } from 'connectkit'
import { useAccount, useSwitchChain } from 'wagmi'
import { AlertTriangle, Wifi } from 'lucide-react'
import { arcTestnet } from '../config'

const ARC_CHAIN_ID = arcTestnet.id

// Simple Arc logo mark (the "A" arc shape)
function ArcIcon({ size = 14 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path
        d="M12 3 C7 3 3 7.5 3 12 C3 16.5 7 21 12 21"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M12 3 C17 3 21 7.5 21 12 C21 16.5 17 21 12 21"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
        fill="none"
        opacity="0.45"
      />
      <circle cx="12" cy="12" r="2.5" fill="currentColor" />
    </svg>
  )
}

export function WalletButton() {
  const { chainId, isConnected } = useAccount()
  const { switchChain, isPending } = useSwitchChain()
  const isWrongChain = isConnected && chainId !== ARC_CHAIN_ID

  return (
    <div className="flex items-center gap-3">
      {isWrongChain && (
        <button
          onClick={() => switchChain({ chainId: ARC_CHAIN_ID })}
          disabled={isPending}
          className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition-all"
          style={{
            background: 'rgba(186, 43, 76, 0.10)',
            color: 'var(--danger)',
            border: '1px solid rgba(186, 43, 76, 0.25)',
          }}
        >
          <AlertTriangle size={12} />
          {isPending ? 'Switching…' : 'Switch to Arc Testnet'}
        </button>
      )}

      {isConnected && !isWrongChain && (
        <div
          className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium"
          style={{
            background: 'rgba(26, 128, 71, 0.10)',
            color: 'var(--success)',
            border: '1px solid rgba(26, 128, 71, 0.20)',
          }}
        >
          <ArcIcon size={13} />
          <Wifi size={12} />
          Arc Testnet
        </div>
      )}

      <ConnectKitButton.Custom>
        {({ isConnected, show, address, ensName }) => (
          <button
            onClick={show}
            className="flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition-all active:scale-95"
            style={{
              background: isConnected ? 'var(--surface-strong)' : 'var(--accent)',
              color: isConnected ? 'var(--ink)' : '#fff',
              border: isConnected ? '1px solid var(--border)' : '1px solid transparent',
              boxShadow: isConnected
                ? '0 1px 4px rgba(44,26,14,0.08)'
                : '0 2px 8px rgba(44,26,14,0.25)',
            }}
          >
            {isConnected ? (
              <>
                <span
                  className="inline-block h-2 w-2 rounded-full"
                  style={{ background: 'var(--success)' }}
                />
                <span className="mono text-xs">
                  {ensName ??
                    (address ? `${address.slice(0, 6)}…${address.slice(-4)}` : '')}
                </span>
              </>
            ) : (
              'Connect Wallet'
            )}
          </button>
        )}
      </ConnectKitButton.Custom>
    </div>
  )
}
