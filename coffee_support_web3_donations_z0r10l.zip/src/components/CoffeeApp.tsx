/**
 * Coffee Support — complete UI.
 * Arc Testnet · Test USDC · No real funds.
 * Tabs: Donate | Profile | Admin
 */

import { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAccount, useSwitchChain, useWriteContract, usePublicClient } from 'wagmi'
import { ConnectKitButton } from 'connectkit'
import { erc20Abi } from 'viem'
import { AlertTriangle, CheckCircle, Loader2, AlertCircle, X, ExternalLink, ChevronUp, Pencil } from 'lucide-react'
import { arcTestnet } from '../config'
import { USDC_ADDRESS, RECIPIENT_ADDRESS } from '../constants'
import { parseAmount } from '@/onchain-money'
import { buildTxExplorerUrl } from '@/onchain-facts'
import { coffeeProfileAbi } from '../coffeeProfileAbi'
import { ProfileTab } from './ProfileTab'
import { AdminDashboard } from './AdminDashboard'

// ─── Chain ───────────────────────────────────────────────────────────────────

const CHAIN_ID = arcTestnet.id
const CONTRACT_ADDRESS = import.meta.env.VITE_COFFEE_PROFILE_ADDRESS as `0x${string}` | undefined
const ADMIN_ADDRESS = (import.meta.env.VITE_ADMIN_ADDRESS as string ?? '').toLowerCase()

// ─── Data ────────────────────────────────────────────────────────────────────

const COFFEES = [
  { id: 'americano',         name: 'Americano',         note: 'Bold & dark' },
  { id: 'latte',             name: 'Caffè Latte',       note: 'Smooth milk' },
  { id: 'cappuccino',        name: 'Cappuccino',        note: 'Thick foam' },
  { id: 'caramel-macchiato', name: 'Caramel Macchiato', note: 'Sweet drizzle' },
  { id: 'flat-white',        name: 'Flat White',        note: 'Velvety micro' },
]

const TIERS = [
  { id: 'full',    label: '1 Coffee',  fraction: '1',  amount: 4 },
  { id: 'half',    label: '½ Coffee',  fraction: '½',  amount: 2 },
  { id: 'quarter', label: '¼ Coffee',  fraction: '¼',  amount: 1 },
]

type AppTab = 'donate' | 'profile' | 'admin'

// ─── Coffee SVG ──────────────────────────────────────────────────────────────

function Cup({ id, size = 48 }: { id: string; size?: number }) {
  const s = size
  if (id === 'latte') return (
    <svg width={s} height={s} viewBox="0 0 48 48" fill="none">
      <rect x="12" y="8"  width="24" height="32" rx="4" fill="#d4a96a" opacity=".3"/>
      <rect x="12" y="24" width="24" height="16" rx="3" fill="#f5dfa0" opacity=".6"/>
      <rect x="12" y="8"  width="24" height="12" rx="3" fill="#6b3a10" opacity=".45"/>
      <ellipse cx="24" cy="8" rx="12" ry="3.5" fill="#f8eedc" opacity=".85"/>
      <path d="M18 10 Q24 7 30 10" stroke="#9a6228" strokeWidth="1.4" fill="none" strokeLinecap="round"/>
      <path d="M36 16 Q43 14 41 26 Q39 33 36 31" stroke="#8a5520" strokeWidth="2.2" strokeLinecap="round" fill="none"/>
    </svg>
  )
  if (id === 'cappuccino') return (
    <svg width={s} height={s} viewBox="0 0 48 48" fill="none">
      <path d="M12 20 L14 40 Q14 43 18 43 H30 Q34 43 34 40 L36 20 Z" fill="#c89050" opacity=".3"/>
      <ellipse cx="24" cy="20" rx="12" ry="4.5" fill="#ddb870" opacity=".55"/>
      <ellipse cx="24" cy="18" rx="10" ry="5" fill="#f8eedc" opacity=".9"/>
      <path d="M19 17 Q24 13 29 17" stroke="#b07830" strokeWidth="1.4" fill="none" strokeLinecap="round"/>
      <circle cx="24" cy="18" r="2.5" fill="#c08040" opacity=".25"/>
      <path d="M36 26 Q43 22 41 32 Q39 38 36 36" stroke="#8a5520" strokeWidth="2.2" strokeLinecap="round" fill="none"/>
    </svg>
  )
  if (id === 'caramel-macchiato') return (
    <svg width={s} height={s} viewBox="0 0 48 48" fill="none">
      <rect x="11" y="10" width="26" height="30" rx="4" fill="#d4a030" opacity=".22"/>
      <rect x="11" y="26" width="26" height="14" rx="3" fill="#f5d88a" opacity=".6"/>
      <rect x="11" y="10" width="26" height="10" rx="3" fill="#5a2205" opacity=".5"/>
      <path d="M15 12 Q19 8 24 12 Q28 8 33 12" stroke="#c87808" strokeWidth="1.8" fill="none" strokeLinecap="round"/>
      <path d="M37 19 Q44 17 42 28 Q40 36 37 34" stroke="#9a6010" strokeWidth="2.2" strokeLinecap="round" fill="none"/>
    </svg>
  )
  if (id === 'flat-white') return (
    <svg width={s} height={s} viewBox="0 0 48 48" fill="none">
      <path d="M10 22 L13 40 Q13 43 17 43 H31 Q35 43 35 40 L38 22 Z" fill="#c8a878" opacity=".28"/>
      <ellipse cx="24" cy="22" rx="14" ry="5" fill="#e8d4a8" opacity=".65"/>
      <ellipse cx="24" cy="21" rx="12" ry="4" fill="#f8f0e0" opacity=".92"/>
      <path d="M19 20 Q22 16 24 20 Q27 16 30 20" stroke="#a07030" strokeWidth="1.4" fill="none" strokeLinecap="round"/>
      <path d="M38 28 Q45 24 43 34 Q41 41 38 39" stroke="#8a5520" strokeWidth="2.2" strokeLinecap="round" fill="none"/>
    </svg>
  )
  // americano
  return (
    <svg width={s} height={s} viewBox="0 0 48 48" fill="none">
      <path d="M12 20 L15 40 Q15 43 19 43 H29 Q33 43 33 40 L36 20 Z" fill="#3c1905" opacity=".22"/>
      <ellipse cx="24" cy="20" rx="12" ry="4.5" fill="#a06830" opacity=".55"/>
      <ellipse cx="24" cy="22" rx="9" ry="3" fill="#321203" opacity=".6"/>
      <ellipse cx="24" cy="22" rx="9" ry="3" fill="none" stroke="#b47828" strokeWidth="1.2" opacity=".4"/>
      <path d="M21 15 Q22 11 20 9" stroke="#3c1905" strokeWidth="1.3" strokeLinecap="round" fill="none" opacity=".3"/>
      <path d="M24 13 Q25 9 23 7"  stroke="#3c1905" strokeWidth="1.3" strokeLinecap="round" fill="none" opacity=".25"/>
      <path d="M27 15 Q28 11 26 9" stroke="#3c1905" strokeWidth="1.3" strokeLinecap="round" fill="none" opacity=".3"/>
      <path d="M36 26 Q43 22 41 32 Q39 38 36 36" stroke="#3c1905" strokeWidth="2.2" strokeLinecap="round" fill="none" opacity=".4"/>
    </svg>
  )
}

// ─── Donate hook ─────────────────────────────────────────────────────────────

type TxPhase = 'idle' | 'waiting' | 'submitted' | 'confirming' | 'success' | 'error'
interface Pending { coffeeName: string; fraction: string; amount: number }

function useDonate() {
  const { address, chainId } = useAccount()
  const { switchChainAsync } = useSwitchChain()
  const { writeContractAsync } = useWriteContract()
  const publicClient = usePublicClient({ chainId: CHAIN_ID })

  const [pending, setPending]       = useState<Pending | null>(null)
  const [phase, setPhase]           = useState<TxPhase>('idle')
  const [txHash, setTxHash]         = useState<`0x${string}` | undefined>()
  const [errMsg, setErrMsg]         = useState<string | undefined>()
  const [customAddr, setCustomAddr] = useState('')
  const [history, setHistory]       = useState<Array<{ id: string; coffeeName: string; amount: number; address: string; txHash: string; ts: number }>>([])

  const open = useCallback((coffeeName: string, fraction: string, amount: number) => {
    setPending({ coffeeName, fraction, amount })
    setPhase('idle'); setTxHash(undefined); setErrMsg(undefined)
  }, [])

  const close = useCallback(() => {
    if (phase === 'waiting' || phase === 'submitted' || phase === 'confirming') return
    setPending(null); setPhase('idle'); setTxHash(undefined); setErrMsg(undefined)
  }, [phase])

  const retry = useCallback(() => { setPhase('idle'); setErrMsg(undefined); setTxHash(undefined) }, [])

  const confirm = useCallback(async () => {
    if (!pending) return
    const recipient = (customAddr.trim() || RECIPIENT_ADDRESS || address) as `0x${string}` | undefined
    if (!recipient) return
    try {
      if (chainId !== CHAIN_ID) { setPhase('waiting'); await switchChainAsync({ chainId: CHAIN_ID }) }
      setPhase('waiting')
      const parsed = parseAmount(CHAIN_ID, String(pending.amount))
      const hash = await writeContractAsync({
        address: USDC_ADDRESS,
        abi: erc20Abi,
        functionName: 'transfer',
        args: [recipient, parsed.raw],
      })
      setTxHash(hash); setPhase('submitted'); setPhase('confirming')
      if (!publicClient) throw new Error('No RPC client')
      await publicClient.waitForTransactionReceipt({ hash })
      setPhase('success')
      const rec = { id: hash, coffeeName: pending.coffeeName, amount: pending.amount, address: address ?? '', txHash: hash, ts: Date.now() }
      setHistory(h => [rec, ...h.slice(0, 9)])

      // Record donation onchain (fire-and-forget — non-blocking)
      if (CONTRACT_ADDRESS && address) {
        writeContractAsync({
          address: CONTRACT_ADDRESS,
          abi: coffeeProfileAbi,
          functionName: 'recordDonation',
          args: [address, pending.coffeeName, BigInt(pending.amount), pending.fraction],
        }).catch(() => { /* silent — recording is best-effort */ })
      }
    } catch (e) {
      const msg = ((e as { message?: string }).message ?? '').toLowerCase()
      if (msg.includes('user rejected') || (e as { code?: number }).code === 4001) { setPhase('idle'); return }
      setPhase('error'); setErrMsg(((e as { message?: string }).message ?? 'Something went wrong.').slice(0, 120))
    }
  }, [pending, customAddr, address, chainId, switchChainAsync, writeContractAsync, publicClient])

  return { pending, phase, txHash, errMsg, history, address, chainId, open, close, retry, confirm, customAddr, setCustomAddr }
}

// ─── Wallet bar ──────────────────────────────────────────────────────────────

function WalletBar({ activeTab, setActiveTab }: { activeTab: AppTab; setActiveTab: (t: AppTab) => void }) {
  const { chainId, isConnected, address } = useAccount()
  const { switchChain, isPending } = useSwitchChain()
  const wrong = isConnected && chainId !== CHAIN_ID
  const isAdmin = isConnected && address?.toLowerCase() === ADMIN_ADDRESS

  const tabStyle = (id: AppTab): React.CSSProperties => ({
    padding: '6px 14px',
    borderRadius: 20,
    border: 'none',
    fontSize: 12,
    fontWeight: 700,
    cursor: 'pointer',
    fontFamily: 'system-ui,sans-serif',
    background: activeTab === id ? '#2c1a0e' : 'transparent',
    color: activeTab === id ? '#fff' : '#7a5c44',
  })

  return (
    <div style={{ position: 'sticky', top: 0, zIndex: 30, background: 'rgba(255,251,246,0.95)', backdropFilter: 'blur(16px)', borderBottom: '1px solid rgba(44,26,14,0.08)', WebkitBackdropFilter: 'blur(16px)' }}>
      <div style={{ maxWidth: 720, margin: '0 auto', padding: '10px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>

        {/* Logo + Tabs */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <span style={{ fontSize: 18, marginRight: 6 }}>☕</span>
          <button onClick={() => setActiveTab('donate')} style={tabStyle('donate')}>Donate</button>
          {isConnected && <button onClick={() => setActiveTab('profile')} style={tabStyle('profile')}>Profilim</button>}
          {isAdmin && <button onClick={() => setActiveTab('admin')} style={{ ...tabStyle('admin'), background: activeTab === 'admin' ? '#1a8047' : 'rgba(26,128,71,0.10)', color: activeTab === 'admin' ? '#fff' : '#1a8047' }}>⚙ Admin</button>}
        </div>

        {/* Right side */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          {wrong && (
            <button onClick={() => switchChain({ chainId: CHAIN_ID })} disabled={isPending}
              style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '5px 10px', borderRadius: 20, background: 'rgba(186,43,76,0.10)', color: '#ba2b4c', border: '1px solid rgba(186,43,76,0.25)', fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: 'system-ui,sans-serif' }}>
              <AlertTriangle size={11} />{isPending ? 'Switching…' : 'Switch to Arc'}
            </button>
          )}
          {isConnected && !wrong && (
            <span style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '5px 10px', borderRadius: 20, background: 'rgba(26,128,71,0.10)', color: '#1a8047', border: '1px solid rgba(26,128,71,0.20)', fontSize: 11, fontWeight: 600 }}>
              ⬡ Arc Testnet
            </span>
          )}
          <ConnectKitButton.Custom>
            {({ isConnected: con, show, address: addr, ensName }) => (
              <button onClick={show}
                style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px', borderRadius: 20, background: con ? '#fff' : '#2c1a0e', color: con ? '#2c1a0e' : '#fff', border: con ? '1px solid rgba(44,26,14,0.18)' : 'none', fontSize: 12, fontWeight: 600, cursor: 'pointer', boxShadow: con ? '0 1px 4px rgba(44,26,14,0.10)' : '0 2px 8px rgba(44,26,14,0.28)', fontFamily: 'system-ui,sans-serif' }}>
                {con && <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#1a8047', display: 'inline-block' }} />}
                {con ? (ensName ?? (addr ? `${addr.slice(0, 6)}…${addr.slice(-4)}` : '')) : 'Connect Wallet'}
              </button>
            )}
          </ConnectKitButton.Custom>
        </div>
      </div>
    </div>
  )
}

// ─── Modal ───────────────────────────────────────────────────────────────────

function Modal({ hook }: { hook: ReturnType<typeof useDonate> }) {
  const { pending, phase, txHash, errMsg, close, confirm, retry, customAddr, setCustomAddr, address } = hook
  const [showEditor, setShowEditor] = useState(false)

  const defaultRecipient = RECIPIENT_ADDRESS || address || ''
  const effective = customAddr.trim() || defaultRecipient
  const fmt = (a: string) => a ? `${a.slice(0, 6)}…${a.slice(-4)}` : 'Not set'
  const isCustom = Boolean(customAddr.trim()) && customAddr.trim() !== defaultRecipient
  const badAddr = Boolean(customAddr.trim()) && !/^0x[0-9a-fA-F]{40}$/.test(customAddr.trim())
  const canConfirm = Boolean(effective) && !badAddr

  const idle = phase === 'idle'
  const busy = phase === 'waiting' || phase === 'submitted' || phase === 'confirming'
  const done = phase === 'success' || phase === 'error'

  if (!pending) return null

  return (
    <AnimatePresence>
      <motion.div key="bd" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        onClick={!busy ? close : undefined}
        style={{ position: 'fixed', inset: 0, zIndex: 40, background: 'rgba(22,13,5,0.55)', backdropFilter: 'blur(6px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
        <motion.div key="panel" initial={{ scale: 0.92, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 10 }}
          transition={{ type: 'spring', stiffness: 380, damping: 30 }}
          onClick={e => e.stopPropagation()}
          style={{ background: '#fff', borderRadius: 24, width: '100%', maxWidth: 400, overflow: 'hidden', boxShadow: '0 24px 64px rgba(22,13,5,0.22)', fontFamily: 'system-ui,sans-serif' }}>

          <div style={{ height: 4, background: 'linear-gradient(90deg,#60a5fa,#a78bfa,#f87171,#fbbf24,#34d399)' }} />

          {(idle || done) && (
            <button onClick={close} style={{ position: 'absolute', top: 52, right: 18, width: 28, height: 28, borderRadius: '50%', background: '#f5f0eb', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9c7b62' }}>
              <X size={14} />
            </button>
          )}

          <div style={{ padding: '20px 24px 24px' }}>
            {idle && (
              <>
                <p style={{ fontSize: 18, fontWeight: 700, color: '#2c1a0e', margin: '0 0 16px' }}>Coffee Donation ☕</p>
                <div style={{ background: 'linear-gradient(135deg,rgba(44,26,14,0.05),rgba(196,154,108,0.12))', border: '1px solid rgba(44,26,14,0.09)', borderRadius: 16, padding: '18px 16px', textAlign: 'center', marginBottom: 12 }}>
                  <p style={{ fontSize: 11, fontWeight: 600, color: '#9c7b62', textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 4px' }}>Gönderiliyor</p>
                  <p style={{ fontSize: 42, fontWeight: 800, color: '#2c1a0e', margin: '0 0 2px', letterSpacing: '-0.04em' }}>{pending.amount} <span style={{ fontSize: 22 }}>USDC</span></p>
                  <p style={{ fontSize: 13, color: '#7a5c44', margin: 0 }}>{pending.fraction} Coffee · {pending.coffeeName}</p>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#faf5f0', border: '1px solid rgba(44,26,14,0.08)', borderRadius: 12, padding: '10px 14px', marginBottom: 8 }}>
                  <span style={{ fontSize: 13, color: '#7a5c44' }}>Network</span>
                  <span style={{ fontSize: 13, fontWeight: 600, color: '#2c1a0e' }}>Arc Testnet</span>
                </div>
                <div style={{ border: '1px solid rgba(44,26,14,0.08)', borderRadius: 12, overflow: 'hidden', marginBottom: 16 }}>
                  <button onClick={() => setShowEditor(v => !v)}
                    style={{ width: '100%', background: '#faf5f0', border: 'none', padding: '10px 14px', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 13, color: '#7a5c44' }}>Recipient</span>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={{ fontSize: 13, fontWeight: 600, color: isCustom ? '#5b6bf5' : '#2c1a0e', fontFamily: 'monospace' }}>{fmt(effective)}</span>
                      {isCustom && <span style={{ fontSize: 10, fontWeight: 700, background: 'rgba(91,107,245,0.12)', color: '#5b6bf5', borderRadius: 8, padding: '2px 6px' }}>custom</span>}
                      <span style={{ color: '#9c7b62' }}>{showEditor ? <ChevronUp size={13} /> : <Pencil size={13} />}</span>
                    </div>
                  </button>
                  <AnimatePresence>
                    {showEditor && (
                      <motion.div key="ed" initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} style={{ overflow: 'hidden' }}>
                        <div style={{ padding: '10px 14px 12px', borderTop: '1px solid rgba(44,26,14,0.07)', background: 'rgba(255,255,255,0.6)' }}>
                          <p style={{ fontSize: 11, color: '#9c7b62', margin: '0 0 6px' }}>Varsayılan: <span style={{ fontFamily: 'monospace', fontWeight: 600 }}>{fmt(defaultRecipient)}</span>{defaultRecipient === address && ' (senin cüzdanın)'}</p>
                          <input value={customAddr} onChange={e => setCustomAddr(e.target.value)} placeholder="Özel adres (0x…)" spellCheck={false}
                            style={{ width: '100%', padding: '8px 10px', borderRadius: 8, border: `1px solid ${badAddr ? '#ba2b4c' : 'rgba(44,26,14,0.14)'}`, fontSize: 12, fontFamily: 'monospace', background: '#fff', color: '#2c1a0e', outline: 'none', boxSizing: 'border-box' }} />
                          {badAddr && <p style={{ fontSize: 11, color: '#ba2b4c', margin: '4px 0 0' }}>Geçersiz adres formatı</p>}
                          {customAddr.trim() && <button onClick={() => { setCustomAddr(''); setShowEditor(false) }} style={{ fontSize: 11, color: '#9c7b62', background: 'none', border: 'none', cursor: 'pointer', padding: '4px 0 0', textDecoration: 'underline' }}>Varsayılana dön</button>}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
                <button onClick={() => { void confirm() }} disabled={!canConfirm}
                  style={{ width: '100%', padding: '14px', borderRadius: 12, background: canConfirm ? '#2c1a0e' : 'rgba(44,26,14,0.12)', color: canConfirm ? '#fff' : '#9c7b62', border: 'none', fontSize: 14, fontWeight: 700, cursor: canConfirm ? 'pointer' : 'not-allowed', marginBottom: 8, boxShadow: canConfirm ? '0 4px 14px rgba(44,26,14,0.30)' : 'none', fontFamily: 'system-ui,sans-serif' }}>
                  Onayla · {pending.amount} USDC
                </button>
                <button onClick={close} style={{ width: '100%', padding: '12px', borderRadius: 12, background: '#faf5f0', color: '#4a2c1a', border: '1px solid rgba(44,26,14,0.10)', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'system-ui,sans-serif' }}>
                  İptal
                </button>
              </>
            )}
            {busy && (
              <div style={{ textAlign: 'center', padding: '8px 0 8px' }}>
                <p style={{ fontSize: 18, fontWeight: 700, color: '#2c1a0e', margin: '0 0 20px' }}>İşleniyor…</p>
                <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'rgba(196,154,108,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                  <Loader2 size={28} className="animate-spin" style={{ color: '#c49a6c' }} />
                </div>
                <p style={{ fontSize: 28, fontWeight: 800, color: '#2c1a0e', margin: '0 0 8px' }}>{pending.amount} USDC</p>
                <p style={{ fontSize: 13, color: '#7a5c44', margin: '0 0 12px' }}>
                  {phase === 'waiting' ? 'Cüzdan onayı bekleniyor…' : phase === 'submitted' ? 'Ağa gönderildi…' : 'Onaylanıyor…'}
                </p>
                {txHash && (
                  <a href={buildTxExplorerUrl(CHAIN_ID, txHash)} target="_blank" rel="noopener noreferrer"
                    style={{ fontSize: 12, color: '#5b6bf5', textDecoration: 'underline', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                    Explorer'da gör <ExternalLink size={11} />
                  </a>
                )}
              </div>
            )}
            {phase === 'success' && (
              <div style={{ textAlign: 'center' }}>
                <p style={{ fontSize: 18, fontWeight: 700, color: '#1a8047', margin: '0 0 16px' }}>☕ Kahve gönderildi!</p>
                <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'rgba(26,128,71,0.10)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px' }}>
                  <CheckCircle size={32} style={{ color: '#1a8047' }} />
                </div>
                <p style={{ fontSize: 36, fontWeight: 800, color: '#2c1a0e', margin: '0 0 6px' }}>{pending.amount} USDC</p>
                <p style={{ fontSize: 13, color: '#7a5c44', margin: '0 0 16px' }}>Kahven için teşekkürler!</p>
                {txHash && (
                  <>
                    <div style={{ background: '#faf5f0', border: '1px solid rgba(44,26,14,0.08)', borderRadius: 10, padding: '10px 12px', marginBottom: 12, textAlign: 'left' }}>
                      <p style={{ fontSize: 11, color: '#9c7b62', margin: '0 0 2px' }}>İşlem</p>
                      <p style={{ fontSize: 11, fontFamily: 'monospace', color: '#4a2c1a', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{txHash}</p>
                    </div>
                    <a href={buildTxExplorerUrl(CHAIN_ID, txHash)} target="_blank" rel="noopener noreferrer"
                      style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '10px 20px', borderRadius: 10, background: '#2c1a0e', color: '#fff', fontSize: 13, fontWeight: 600, textDecoration: 'none', marginBottom: 10 }}>
                      Arc Explorer'da Gör <ExternalLink size={12} />
                    </a>
                  </>
                )}
                <button onClick={close} style={{ width: '100%', padding: '12px', borderRadius: 12, background: '#faf5f0', color: '#4a2c1a', border: '1px solid rgba(44,26,14,0.10)', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'system-ui,sans-serif' }}>Tamam</button>
              </div>
            )}
            {phase === 'error' && (
              <>
                <p style={{ fontSize: 18, fontWeight: 700, color: '#ba2b4c', margin: '0 0 12px' }}>Bir hata oluştu</p>
                <div style={{ background: 'rgba(186,43,76,0.07)', border: '1px solid rgba(186,43,76,0.18)', borderRadius: 12, padding: '12px 14px', marginBottom: 14, display: 'flex', gap: 10 }}>
                  <AlertCircle size={16} style={{ color: '#ba2b4c', flexShrink: 0, marginTop: 1 }} />
                  <p style={{ fontSize: 13, color: '#ba2b4c', margin: 0 }}>{errMsg ?? 'Bilinmeyen hata. Tekrar dene.'}</p>
                </div>
                <button onClick={retry} style={{ width: '100%', padding: '13px', borderRadius: 12, background: '#2c1a0e', color: '#fff', border: 'none', fontSize: 14, fontWeight: 700, cursor: 'pointer', marginBottom: 8, fontFamily: 'system-ui,sans-serif' }}>Tekrar Dene</button>
                <button onClick={close} style={{ width: '100%', padding: '12px', borderRadius: 12, background: '#faf5f0', color: '#4a2c1a', border: '1px solid rgba(44,26,14,0.10)', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'system-ui,sans-serif' }}>İptal</button>
              </>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

// ─── Donate Tab ───────────────────────────────────────────────────────────────

function DonateTab({ hook }: { hook: ReturnType<typeof useDonate> }) {
  const { phase, history } = hook
  const [selectedCoffee, setSelectedCoffee] = useState(COFFEES[0].id)
  const [selectedTier, setSelectedTier]     = useState(TIERS[0].id)
  const { isConnected } = useAccount()

  const coffee = COFFEES.find(c => c.id === selectedCoffee) ?? COFFEES[0]
  const tier   = TIERS.find(t => t.id === selectedTier) ?? TIERS[0]

  const cardBase: React.CSSProperties = { background: '#fff', borderRadius: 16, padding: 0, border: '1.5px solid rgba(44,26,14,0.10)', boxShadow: '0 2px 12px rgba(44,26,14,0.07)', cursor: 'pointer', transition: 'box-shadow 0.15s, border-color 0.15s', display: 'flex', flexDirection: 'column', alignItems: 'center', overflow: 'hidden', fontFamily: 'system-ui,sans-serif' }
  const cardSel: React.CSSProperties = { ...cardBase, border: '2px solid #2c1a0e', boxShadow: '0 4px 20px rgba(44,26,14,0.14)' }
  const pill: React.CSSProperties = { flex: 1, padding: '12px 8px', borderRadius: 12, border: '1.5px solid rgba(44,26,14,0.08)', background: '#faf5f0', cursor: 'pointer', textAlign: 'center', fontFamily: 'system-ui,sans-serif' }
  const pillSel: React.CSSProperties = { ...pill, background: '#2c1a0e', border: '1.5px solid #2c1a0e' }
  const isLoading = phase === 'waiting' || phase === 'submitted' || phase === 'confirming'

  return (
    <>
      {/* Hero */}
      <div style={{ textAlign: 'center', padding: '28px 0 32px' }}>
        <div style={{ fontSize: 48, marginBottom: 12 }}>☕</div>
        <h1 style={{ fontSize: 28, fontWeight: 800, color: '#2c1a0e', margin: '0 0 8px', letterSpacing: '-0.03em' }}>Fuel My Day With Coffee</h1>
        <p style={{ fontSize: 14, color: '#7a5c44', margin: '0 0 14px' }}>Küçük bir onchain bağış — büyük bir teşvik.</p>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '6px 14px', borderRadius: 20, background: 'rgba(255,255,255,0.80)', border: '1px solid rgba(44,26,14,0.10)', fontSize: 12, fontWeight: 600, color: '#7a5c44' }}>
          ⬡ Arc Testnet · Test USDC · Gerçek para yok
        </span>
      </div>

      {/* Panel */}
      <div style={{ background: '#fff', borderRadius: 20, border: '1px solid rgba(44,26,14,0.10)', boxShadow: '0 4px 24px rgba(44,26,14,0.07)', overflow: 'hidden' }}>
        <div style={{ height: 4, background: 'linear-gradient(90deg,#60a5fa,#a78bfa,#f87171,#fbbf24,#34d399)' }} />
        <div style={{ padding: '20px 20px 24px' }}>
          <p style={{ fontSize: 11, fontWeight: 600, color: '#9c7b62', textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 10px' }}>1 · Kahve Seç</p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 8, marginBottom: 20 }}>
            {COFFEES.map(c => (
              <button key={c.id} onClick={() => setSelectedCoffee(c.id)} style={c.id === selectedCoffee ? cardSel : cardBase}>
                <div style={{ padding: '10px 8px 4px', display: 'flex', justifyContent: 'center' }}><Cup id={c.id} size={44} /></div>
                <div style={{ padding: '0 6px 10px', textAlign: 'center' }}>
                  <p style={{ fontSize: 11, fontWeight: 700, color: '#2c1a0e', margin: '0 0 2px', lineHeight: 1.3 }}>{c.name}</p>
                  <p style={{ fontSize: 10, color: '#9c7b62', margin: 0, lineHeight: 1.3 }}>{c.note}</p>
                </div>
              </button>
            ))}
          </div>
          <p style={{ fontSize: 11, fontWeight: 600, color: '#9c7b62', textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 10px' }}>2 · Boyut Seç</p>
          <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
            {TIERS.map(t => (
              <button key={t.id} onClick={() => setSelectedTier(t.id)} style={t.id === selectedTier ? pillSel : pill}>
                <p style={{ fontSize: 18, fontWeight: 800, margin: '0 0 2px', color: t.id === selectedTier ? '#fff' : '#2c1a0e' }}>{t.fraction}</p>
                <p style={{ fontSize: 11, fontWeight: 600, margin: '0 0 2px', color: t.id === selectedTier ? 'rgba(255,255,255,0.85)' : '#7a5c44' }}>{t.id === 'full' ? 'Full' : t.id === 'half' ? 'Half' : 'Quarter'}</p>
                <p style={{ fontSize: 12, fontWeight: 700, margin: 0, color: t.id === selectedTier ? '#fbbf24' : '#2c1a0e' }}>{t.amount} USDC</p>
              </button>
            ))}
          </div>
          <div style={{ background: 'rgba(44,26,14,0.04)', border: '1px solid rgba(44,26,14,0.08)', borderRadius: 14, padding: '14px 16px', marginBottom: 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <p style={{ fontSize: 11, fontWeight: 600, color: '#9c7b62', textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 2px' }}>Miktar</p>
              <p style={{ fontSize: 32, fontWeight: 800, color: '#2c1a0e', margin: '0 0 2px', letterSpacing: '-0.04em' }}>{tier.amount} <span style={{ fontSize: 16, fontWeight: 600, color: '#7a5c44' }}>USDC</span></p>
              <p style={{ fontSize: 12, color: '#9c7b62', margin: 0 }}>{tier.fraction} {coffee.name} · Test USDC</p>
            </div>
            <Cup id={coffee.id} size={48} />
          </div>
          <button disabled={!isConnected || isLoading} onClick={() => hook.open(coffee.name, tier.fraction, tier.amount)}
            style={{ width: '100%', padding: '15px', borderRadius: 13, background: (!isConnected || isLoading) ? 'rgba(44,26,14,0.10)' : '#2c1a0e', color: (!isConnected || isLoading) ? '#9c7b62' : '#fff', border: 'none', fontSize: 15, fontWeight: 700, cursor: (!isConnected || isLoading) ? 'not-allowed' : 'pointer', letterSpacing: '0.01em', boxShadow: (!isConnected || isLoading) ? 'none' : '0 4px 16px rgba(44,26,14,0.28)', fontFamily: 'system-ui,sans-serif' }}>
            {!isConnected ? 'Bağış için cüzdanını bağla' : `Donate ${tier.amount} USDC`}
          </button>
        </div>
      </div>

      {/* History */}
      {history.length > 0 && (
        <div style={{ marginTop: 32 }}>
          <p style={{ fontSize: 13, fontWeight: 700, color: '#2c1a0e', margin: '0 0 12px' }}>Son Bağışlar</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {history.map(h => (
              <div key={h.id} style={{ background: '#fff', border: '1px solid rgba(44,26,14,0.08)', borderRadius: 14, padding: '12px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <p style={{ fontSize: 13, fontWeight: 700, color: '#2c1a0e', margin: '0 0 2px' }}>☕ {h.coffeeName}</p>
                  <p style={{ fontSize: 11, color: '#9c7b62', margin: 0, fontFamily: 'monospace' }}>{h.address.slice(0, 6)}…{h.address.slice(-4)}</p>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <p style={{ fontSize: 14, fontWeight: 800, color: '#2c1a0e', margin: '0 0 2px' }}>{h.amount} USDC</p>
                  <a href={buildTxExplorerUrl(CHAIN_ID, h.txHash)} target="_blank" rel="noopener noreferrer"
                    style={{ fontSize: 11, color: '#5b6bf5', textDecoration: 'underline' }}>Explorer</a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Footer */}
      <div style={{ textAlign: 'center', marginTop: 48, paddingTop: 24, borderTop: '1px solid rgba(44,26,14,0.08)' }}>
        <p style={{ fontSize: 13, fontWeight: 700, color: '#4a2c1a', margin: '0 0 4px' }}>⬡ Built on Arc</p>
        <p style={{ fontSize: 12, color: '#9c7b62', margin: 0 }}>Testnet versiyonu — Gerçek para kullanılmıyor. Tüm bağışlar Arc Testnet üzerinde Test USDC.</p>
      </div>
    </>
  )
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export function CoffeeApp() {
  const hook = useDonate()
  const [activeTab, setActiveTab] = useState<AppTab>('donate')
  const { address, isConnected } = useAccount()
  const isAdmin = isConnected && address?.toLowerCase() === ADMIN_ADDRESS

  // Render sırasında izin yoksa tab'ı donate'e düşür
  const safeTab: AppTab =
    activeTab === 'admin' && !isAdmin ? 'donate'
    : activeTab === 'profile' && !isConnected ? 'donate'
    : activeTab

  return (
    <div style={{ minHeight: '100dvh', background: 'linear-gradient(180deg,#fdf8f3 0%,#fef9f4 60%,#fdf5ee 100%)', fontFamily: 'system-ui,sans-serif' }}>
      <WalletBar activeTab={safeTab} setActiveTab={setActiveTab} />
      <div style={{ maxWidth: 680, margin: '0 auto', padding: '24px 16px 80px' }}>
        {safeTab === 'donate'  && <DonateTab hook={hook} />}
        {safeTab === 'profile' && <ProfileTab />}
        {safeTab === 'admin'   && <AdminDashboard />}
      </div>
      <Modal hook={hook} />
    </div>
  )
}
