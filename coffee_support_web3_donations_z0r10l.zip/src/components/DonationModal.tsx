import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, ExternalLink, CheckCircle, AlertCircle, Loader2, ChevronUp, Pencil } from 'lucide-react'
import { useAccount } from 'wagmi'
import { CoffeeItem, DonationTier, TARGET_CHAIN, RECIPIENT_ADDRESS } from '../constants'
import { buildTxExplorerUrl } from '@/onchain-facts'

export type TxStatus =
  | 'idle'
  | 'awaiting-approval'
  | 'submitted'
  | 'confirming'
  | 'success'
  | 'error'

export interface PendingDonation {
  coffee: CoffeeItem
  tier: DonationTier
}

interface DonationModalProps {
  donation: PendingDonation | null
  status: TxStatus
  txHash?: `0x${string}`
  errorMessage?: string
  onConfirm: () => void
  onClose: () => void
  onRetry: () => void
  customRecipient: string
  onCustomRecipientChange: (v: string) => void
}

function formatAddress(addr: string) {
  if (!addr || addr.length < 10) return addr
  return `${addr.slice(0, 6)}…${addr.slice(-4)}`
}

const BUSY_LABEL: Record<string, string> = {
  'awaiting-approval': 'Check your wallet and confirm…',
  submitted: 'Transaction submitted to the network…',
  confirming: 'Waiting for block confirmation…',
}

export function DonationModal({
  donation,
  status,
  txHash,
  errorMessage,
  onConfirm,
  onClose,
  onRetry,
  customRecipient,
  onCustomRecipientChange,
}: DonationModalProps) {
  const { address } = useAccount()
  const [showRecipientEditor, setShowRecipientEditor] = useState(false)

  // Effective recipient: custom → env var → connected wallet
  const defaultRecipient = RECIPIENT_ADDRESS || address || ''
  const effectiveRecipient = customRecipient.trim() || defaultRecipient
  const isCustomActive = Boolean(customRecipient.trim()) && customRecipient.trim() !== defaultRecipient

  const recipientDisplay = effectiveRecipient ? formatAddress(effectiveRecipient) : 'Not configured'
  const canConfirm = Boolean(effectiveRecipient)

  const isOpen = donation !== null
  const isBusy = ['awaiting-approval', 'submitted', 'confirming'].includes(status)
  const isSuccess = status === 'success'
  const isError = status === 'error'
  const isIdle = status === 'idle'
  const isDone = isSuccess || isError

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* ── Backdrop ── */}
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22 }}
            className="fixed inset-0 z-40 flex items-center justify-center"
            style={{
              background: 'rgba(22,13,5,0.55)',
              backdropFilter: 'blur(6px)',
              WebkitBackdropFilter: 'blur(6px)',
            }}
            onClick={isDone || isIdle ? onClose : undefined}
          />

          {/* ── Modal panel — always dead-centre ── */}
          <motion.div
            key="modal"
            initial={{ opacity: 0, scale: 0.93, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 12 }}
            transition={{ type: 'spring', stiffness: 380, damping: 30 }}
            className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none px-4"
          >
            <div
              className="pointer-events-auto relative w-full max-w-sm rounded-3xl overflow-hidden"
              style={{
                background: 'rgba(255,255,255,0.97)',
                backdropFilter: 'blur(40px) saturate(200%)',
                WebkitBackdropFilter: 'blur(40px) saturate(200%)',
                border: '1px solid rgba(255,255,255,0.85)',
                boxShadow: '0 32px 80px rgba(22,13,5,0.25), 0 6px 20px rgba(22,13,5,0.10)',
              }}
            >
              {/* Spectral top strip */}
              <div style={{ height: 3, background: 'linear-gradient(90deg, #5fbeff, #af8ff4, #f05c6b, #ffcd83, #7ef1b3)' }} />

              {/* Close button */}
              {(isIdle || isDone) && (
                <button
                  onClick={onClose}
                  className="absolute right-4 top-4 flex h-7 w-7 items-center justify-center rounded-full transition-opacity hover:opacity-70"
                  style={{ background: 'var(--surface-muted)', color: 'var(--subtle)' }}
                >
                  <X size={14} />
                </button>
              )}

              <div className="px-6 pb-7 pt-5">

                {/* ── IDLE: Confirm sheet ──────────────────────────────── */}
                {isIdle && donation && (
                  <>
                    <p className="display text-xl font-bold" style={{ color: 'var(--ink)' }}>
                      Coffee Donation ☕
                    </p>

                    {/* Amount hero */}
                    <div
                      className="mt-4 flex flex-col items-center gap-1 rounded-2xl py-5"
                      style={{
                        background: 'linear-gradient(135deg, rgba(44,26,14,0.06) 0%, rgba(196,154,108,0.14) 100%)',
                        border: '1px solid rgba(44,26,14,0.10)',
                      }}
                    >
                      <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)' }}>
                        You are sending
                      </span>
                      <span className="display text-5xl font-bold tabular-nums" style={{ color: 'var(--accent)', letterSpacing: '-0.04em' }}>
                        {donation.tier.amount} USDC
                      </span>
                      <span className="text-sm font-medium" style={{ color: 'var(--muted)' }}>
                        {donation.tier.fraction} Coffee · {donation.coffee.name}
                      </span>
                    </div>

                    {/* Detail rows */}
                    <div className="mt-3 space-y-2">
                      {/* Network */}
                      <div
                        className="flex items-center justify-between rounded-xl px-4 py-3"
                        style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}
                      >
                        <span className="text-sm" style={{ color: 'var(--muted)' }}>Network</span>
                        <span className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>{TARGET_CHAIN.name}</span>
                      </div>

                      {/* Recipient — collapsible editor */}
                      <div
                        className="rounded-xl overflow-hidden"
                        style={{ border: '1px solid var(--border)' }}
                      >
                        <button
                          className="flex w-full items-center justify-between px-4 py-3 transition-colors hover:opacity-80"
                          style={{ background: 'var(--surface-muted)' }}
                          onClick={() => setShowRecipientEditor((v) => !v)}
                        >
                          <span className="text-sm" style={{ color: 'var(--muted)' }}>Recipient</span>
                          <div className="flex items-center gap-2">
                            <span
                              className="mono text-sm font-semibold tabular-nums"
                              style={{ color: isCustomActive ? 'var(--focus)' : 'var(--ink)' }}
                            >
                              {recipientDisplay}
                            </span>
                            {isCustomActive && (
                              <span
                                className="rounded-full px-1.5 py-0.5 text-[10px] font-bold uppercase"
                                style={{ background: 'rgba(95,130,245,0.12)', color: 'var(--focus)' }}
                              >
                                custom
                              </span>
                            )}
                            <span style={{ color: 'var(--subtle)' }}>
                              {showRecipientEditor ? <ChevronUp size={13} /> : <Pencil size={13} />}
                            </span>
                          </div>
                        </button>

                        {/* Inline address editor */}
                        <AnimatePresence>
                          {showRecipientEditor && (
                            <motion.div
                              key="editor"
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
                              style={{ overflow: 'hidden' }}
                            >
                              <div
                                className="px-4 pb-3 pt-2 space-y-2"
                                style={{ borderTop: '1px solid var(--border)', background: 'rgba(255,255,255,0.60)' }}
                              >
                                <p className="text-xs" style={{ color: 'var(--subtle)' }}>
                                  Default: <span className="mono font-medium">{formatAddress(defaultRecipient)}</span>
                                  {defaultRecipient === address && ' (your wallet)'}
                                </p>
                                <input
                                  type="text"
                                  value={customRecipient}
                                  onChange={(e) => onCustomRecipientChange(e.target.value)}
                                  placeholder={`Custom recipient (e.g. 0x…)`}
                                  spellCheck={false}
                                  className="mono w-full rounded-lg border px-3 py-2.5 text-xs outline-none transition-colors"
                                  style={{
                                    background: 'rgba(255,255,255,0.90)',
                                    borderColor: customRecipient && !/^0x[0-9a-fA-F]{40}$/.test(customRecipient.trim())
                                      ? 'rgba(186,43,76,0.45)'
                                      : 'rgba(44,26,14,0.14)',
                                    color: 'var(--ink)',
                                  }}
                                />
                                {customRecipient.trim() && !/^0x[0-9a-fA-F]{40}$/.test(customRecipient.trim()) && (
                                  <p className="text-xs" style={{ color: 'var(--danger)' }}>
                                    Invalid address format.
                                  </p>
                                )}
                                {customRecipient.trim() && (
                                  <button
                                    className="text-xs underline underline-offset-2"
                                    style={{ color: 'var(--subtle)' }}
                                    onClick={() => { onCustomRecipientChange(''); setShowRecipientEditor(false) }}
                                  >
                                    Reset to default
                                  </button>
                                )}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>

                      {!canConfirm && (
                        <p className="rounded-xl p-3 text-xs" style={{ background: 'rgba(186,43,76,0.07)', color: 'var(--danger)' }}>
                          No recipient configured. Set VITE_RECIPIENT_ADDRESS in .env or connect a wallet.
                        </p>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="mt-5 flex flex-col gap-2">
                      <motion.button
                        whileTap={{ scale: 0.98 }}
                        onClick={onConfirm}
                        disabled={
                          !canConfirm ||
                          Boolean(customRecipient.trim() && !/^0x[0-9a-fA-F]{40}$/.test(customRecipient.trim()))
                        }
                        className="w-full rounded-xl py-4 text-sm font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                        style={{
                          background: 'var(--accent)',
                          color: '#fff',
                          boxShadow: '0 4px 14px rgba(44,26,14,0.32)',
                        }}
                      >
                        Confirm Donation · {donation.tier.amount} USDC
                      </motion.button>
                      <button
                        onClick={onClose}
                        className="w-full rounded-xl py-3.5 text-sm font-semibold transition-colors"
                        style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}
                      >
                        Cancel
                      </button>
                    </div>
                  </>
                )}

                {/* ── IN PROGRESS ─────────────────────────────────────── */}
                {isBusy && (
                  <>
                    <p className="display text-xl font-bold" style={{ color: 'var(--ink)' }}>Processing…</p>
                    <div className="mt-6 flex flex-col items-center gap-4 pb-2">
                      <div className="flex h-14 w-14 items-center justify-center rounded-full"
                        style={{ background: 'rgba(196,154,108,0.15)' }}>
                        <Loader2 size={26} className="animate-spin" style={{ color: 'var(--focus)' }} />
                      </div>
                      {donation && (
                        <p className="display text-3xl font-bold tabular-nums" style={{ color: 'var(--accent)' }}>
                          {donation.tier.amount} USDC
                        </p>
                      )}
                      <p className="text-center text-sm font-medium" style={{ color: 'var(--muted)' }}>
                        {BUSY_LABEL[status] ?? 'Processing…'}
                      </p>
                      {txHash && (
                        <a
                          href={buildTxExplorerUrl(TARGET_CHAIN.chainId, txHash)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 text-xs font-medium underline-offset-2 hover:underline"
                          style={{ color: 'var(--focus)' }}
                        >
                          View on explorer <ExternalLink size={11} />
                        </a>
                      )}
                    </div>
                  </>
                )}

                {/* ── SUCCESS ─────────────────────────────────────────── */}
                {isSuccess && (
                  <>
                    <p className="display text-xl font-bold" style={{ color: 'var(--success)' }}>
                      ☕ Coffee sent!
                    </p>
                    <div className="mt-4 flex flex-col items-center gap-4">
                      <div className="flex h-16 w-16 items-center justify-center rounded-full"
                        style={{ background: 'rgba(26,128,71,0.10)' }}>
                        <CheckCircle size={32} style={{ color: 'var(--success)' }} />
                      </div>
                      {donation && (
                        <p className="display text-4xl font-bold tabular-nums" style={{ color: 'var(--accent)' }}>
                          {donation.tier.amount} USDC
                        </p>
                      )}
                      <p className="text-center text-sm" style={{ color: 'var(--muted)' }}>
                        Thank you for the coffee support!
                      </p>
                      {txHash && (
                        <>
                          <div className="w-full rounded-xl p-3"
                            style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                            <p className="text-xs" style={{ color: 'var(--subtle)' }}>Transaction</p>
                            <p className="mono mt-0.5 truncate text-xs font-medium" style={{ color: 'var(--ink-2)' }}>
                              {txHash}
                            </p>
                          </div>
                          <a
                            href={buildTxExplorerUrl(TARGET_CHAIN.chainId, txHash)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1.5 rounded-xl px-5 py-3 text-sm font-semibold transition-all active:scale-95"
                            style={{ background: 'var(--accent)', color: '#fff', boxShadow: '0 2px 8px rgba(44,26,14,0.25)' }}
                          >
                            View on Arc Testnet Explorer <ExternalLink size={13} />
                          </a>
                        </>
                      )}
                      <button
                        onClick={onClose}
                        className="w-full rounded-xl py-3 text-sm font-semibold"
                        style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}
                      >
                        Done
                      </button>
                    </div>
                  </>
                )}

                {/* ── ERROR ────────────────────────────────────────────── */}
                {isError && (
                  <>
                    <p className="display text-xl font-bold" style={{ color: 'var(--danger)' }}>Something went wrong</p>
                    <div className="mt-4 space-y-4">
                      <div className="flex items-start gap-3 rounded-xl p-4"
                        style={{ background: 'rgba(186,43,76,0.07)', border: '1px solid rgba(186,43,76,0.18)' }}>
                        <AlertCircle size={16} style={{ color: 'var(--danger)', flexShrink: 0, marginTop: 1 }} />
                        <p className="text-sm" style={{ color: 'var(--danger)' }}>
                          {errorMessage ?? 'Something went wrong. Please try again.'}
                        </p>
                      </div>
                      <div className="flex flex-col gap-2">
                        <motion.button
                          whileTap={{ scale: 0.98 }}
                          onClick={onRetry}
                          className="w-full rounded-xl py-3.5 text-sm font-semibold"
                          style={{ background: 'var(--accent)', color: '#fff', boxShadow: '0 2px 8px rgba(44,26,14,0.25)' }}
                        >
                          Try Again
                        </motion.button>
                        <button
                          onClick={onClose}
                          className="w-full rounded-xl py-3.5 text-sm font-semibold"
                          style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </>
                )}

              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
