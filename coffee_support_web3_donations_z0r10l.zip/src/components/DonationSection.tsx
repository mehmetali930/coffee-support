import { motion } from 'framer-motion'
import { COFFEES, DonationTier, CoffeeItem, SECTION_TITLES } from '../constants'
import { CoffeeCard } from './CoffeeCard'

interface DonationSectionProps {
  tier: DonationTier
  onDonate: (coffee: CoffeeItem, tier: DonationTier) => void
  walletConnected: boolean
}

// Spectral strip — only on the section header, used as a thin accent line
const spectral = 'linear-gradient(90deg, #f0a86b, #e87c4a, #c9562e, #7c3a1a)'

// Per-tier warm coffee accent
const TIER_ACCENT: Record<string, { bg: string; border: string }> = {
  full:    { bg: 'rgba(60,28,8,0.06)',  border: 'rgba(60,28,8,0.10)' },
  half:    { bg: 'rgba(140,80,20,0.05)', border: 'rgba(140,80,20,0.09)' },
  quarter: { bg: 'rgba(200,140,60,0.05)', border: 'rgba(200,140,60,0.09)' },
}

// Cup icon per tier size
function TierCupIcon({ tier }: { tier: string }) {
  if (tier === 'full') {
    return (
      <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
        <ellipse cx="18" cy="32" rx="10" ry="3" fill="rgba(60,28,8,0.12)" />
        <path d="M8 14 L10 30 Q10 33 13 33 H23 Q26 33 26 30 L28 14 Z" fill="rgba(60,28,8,0.75)" />
        <ellipse cx="18" cy="14" rx="10" ry="3.5" fill="rgba(100,55,15,0.85)" />
        <ellipse cx="18" cy="15" rx="7.5" ry="2.5" fill="rgba(180,100,30,0.50)" />
        <path d="M28 19 Q32 16 30 23 Q29 27 26 25" stroke="rgba(60,28,8,0.45)" strokeWidth="2.5" strokeLinecap="round" fill="none" />
      </svg>
    )
  }
  if (tier === 'half') {
    return (
      <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
        <ellipse cx="18" cy="32" rx="9" ry="2.5" fill="rgba(140,80,20,0.12)" />
        <path d="M9 16 L11 30 Q11 33 14 33 H22 Q25 33 25 30 L27 16 Z" fill="rgba(193,140,80,0.65)" />
        {/* half-fill line */}
        <rect x="9" y="24" width="18" height="8" rx="0" fill="rgba(255,240,210,0.70)" />
        <ellipse cx="18" cy="16" rx="9" ry="3.5" fill="rgba(240,210,160,0.80)" />
        <path d="M27 20 Q31 17 29 24 Q28 28 25 26" stroke="rgba(140,80,20,0.40)" strokeWidth="2" strokeLinecap="round" fill="none" />
      </svg>
    )
  }
  // quarter
  return (
    <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
      <ellipse cx="18" cy="32" rx="8" ry="2.5" fill="rgba(200,140,60,0.12)" />
      <path d="M10 18 L12 30 Q12 33 15 33 H21 Q24 33 24 30 L26 18 Z" fill="rgba(230,195,120,0.55)" />
      {/* quarter-fill */}
      <rect x="10" y="27" width="16" height="5" rx="0" fill="rgba(255,248,225,0.80)" />
      <ellipse cx="18" cy="18" rx="8" ry="3" fill="rgba(245,220,160,0.80)" />
      <path d="M26 22 Q30 19 28 25 Q27 28 24 27" stroke="rgba(200,140,60,0.40)" strokeWidth="2" strokeLinecap="round" fill="none" />
    </svg>
  )
}

export function DonationSection({ tier, onDonate, walletConnected }: DonationSectionProps) {
  const section = SECTION_TITLES[tier.id] ?? { title: tier.label, subtitle: '' }
  const accent = TIER_ACCENT[tier.id] ?? TIER_ACCENT.full

  return (
    <section className="w-full">
      {/* ── Section header ── */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        className="mb-5 overflow-hidden rounded-2xl"
        style={{
          background: 'rgba(255,255,255,0.82)',
          backdropFilter: 'blur(24px) saturate(160%)',
          WebkitBackdropFilter: 'blur(24px) saturate(160%)',
          border: `1px solid ${accent.border}`,
          boxShadow: '0 4px 24px rgba(44,26,14,0.06)',
        }}
      >
        {/* Thin warm-coffee accent strip */}
        <div style={{ height: 3, background: spectral }} />

        <div className="flex items-center gap-4 px-5 py-4">
          {/* Cup illustration */}
          <div
            className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl"
            style={{ background: accent.bg, border: `1px solid ${accent.border}` }}
          >
            <TierCupIcon tier={tier.id} />
          </div>

          {/* Text */}
          <div className="min-w-0">
            <div className="flex items-baseline gap-2.5 flex-wrap">
              <h2 className="display text-2xl font-bold leading-none" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>
                {tier.fraction} Coffee
              </h2>
              <span
                className="rounded-full px-2.5 py-0.5 text-sm font-bold tabular-nums"
                style={{ background: accent.bg, color: 'var(--accent)', border: `1px solid ${accent.border}` }}
              >
                {tier.amount} USDC
              </span>
            </div>
            <p className="mt-1 text-sm font-medium leading-snug" style={{ color: 'var(--ink-2)' }}>
              {section.title}
            </p>
            <p className="mt-0.5 text-xs leading-snug" style={{ color: 'var(--muted)' }}>
              {section.subtitle}
            </p>
          </div>
        </div>
      </motion.div>

      {/* ── Coffee grid ── */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-5">
        {COFFEES.map((coffee, i) => (
          <motion.div
            key={coffee.id}
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.38, delay: i * 0.06, ease: [0.22, 1, 0.36, 1] }}
          >
            <CoffeeCard
              coffee={coffee}
              tier={tier}
              onDonate={onDonate}
              disabled={!walletConnected}
            />
          </motion.div>
        ))}
      </div>

      {!walletConnected && (
        <p className="mt-3 text-center text-xs" style={{ color: 'var(--subtle)' }}>
          Connect your wallet to donate
        </p>
      )}
    </section>
  )
}
