/**
 * AdminDashboard — sadece admin adresine (0x306e…) açık yönetici paneli.
 * Bağlı cüzdan admin değilse erişim engellenir.
 */

import { useAccount, useReadContract, useWriteContract, usePublicClient } from 'wagmi'
import { useState } from 'react'
import { coffeeProfileAbi } from '../coffeeProfileAbi'
import { Loader2, Users, Coffee, TrendingUp, RefreshCw, ShieldCheck, ShieldOff, UserCheck } from 'lucide-react'

const CONTRACT = import.meta.env.VITE_COFFEE_PROFILE_ADDRESS as `0x${string}`
const ADMIN_ADDRESS = (import.meta.env.VITE_ADMIN_ADDRESS as string ?? '').toLowerCase()
const CHAIN_ID = 5042002 as const

type Donation = { coffeeName: string; amountUsdc: bigint; fraction: string; timestamp: bigint }

const fmt = (a: string) => `${a.slice(0, 6)}…${a.slice(-4)}`
const fmtDate = (ts: bigint) => new Date(Number(ts) * 1000).toLocaleDateString('tr-TR', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })

const card: React.CSSProperties = { background: '#fff', borderRadius: 16, border: '1px solid rgba(44,26,14,0.10)', boxShadow: '0 2px 12px rgba(44,26,14,0.07)', padding: '20px', fontFamily: 'system-ui,sans-serif' }

function StatCard({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub?: string }) {
  return (
    <div style={{ ...card, display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(44,26,14,0.07)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {icon}
      </div>
      <p style={{ fontSize: 11, fontWeight: 600, color: '#9c7b62', textTransform: 'uppercase', letterSpacing: '0.08em', margin: 0 }}>{label}</p>
      <p style={{ fontSize: 28, fontWeight: 800, color: '#2c1a0e', margin: 0, letterSpacing: '-0.03em' }}>{value}</p>
      {sub && <p style={{ fontSize: 11, color: '#9c7b62', margin: 0 }}>{sub}</p>}
    </div>
  )
}

export function AdminDashboard() {
  const { address, isConnected } = useAccount()
  const { writeContractAsync } = useWriteContract()
  const publicClient = usePublicClient({ chainId: CHAIN_ID })

  const isAdmin = isConnected && address?.toLowerCase() === ADMIN_ADDRESS

  // Stats
  const { data: statsData, isLoading: statsLoading, refetch: refetchStats } = useReadContract({
    address: CONTRACT,
    abi: coffeeProfileAbi,
    functionName: 'getStats',
    chainId: CHAIN_ID,
    query: { enabled: isAdmin },
  })

  // All donors
  const { data: donorsData, isLoading: donorsLoading, refetch: refetchDonors } = useReadContract({
    address: CONTRACT,
    abi: coffeeProfileAbi,
    functionName: 'getAllDonors',
    chainId: CHAIN_ID,
    query: { enabled: isAdmin },
  })

  // All donations
  const { data: allDonations, isLoading: donationsLoading, refetch: refetchDonations } = useReadContract({
    address: CONTRACT,
    abi: coffeeProfileAbi,
    functionName: 'getAllDonations',
    chainId: CHAIN_ID,
    query: { enabled: isAdmin },
  })

  // Admin transfer
  const [newAdmin, setNewAdmin] = useState('')
  const [transferring, setTransferring] = useState(false)
  const [transferMsg, setTransferMsg] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<'overview' | 'donors' | 'donations'>('overview')

  const handleRefreshAll = () => {
    void refetchStats()
    void refetchDonors()
    void refetchDonations()
  }

  const handleTransferAdmin = async () => {
    if (!newAdmin.trim() || !/^0x[0-9a-fA-F]{40}$/.test(newAdmin.trim()) || !publicClient) return
    setTransferring(true)
    setTransferMsg(null)
    try {
      const hash = await writeContractAsync({
        address: CONTRACT,
        abi: coffeeProfileAbi,
        functionName: 'transferAdmin',
        args: [newAdmin.trim() as `0x${string}`],
      })
      await publicClient.waitForTransactionReceipt({ hash })
      setTransferMsg(`✅ Admin başarıyla aktarıldı: ${fmt(newAdmin.trim())}`)
      setNewAdmin('')
    } catch (e) {
      const msg = ((e as { message?: string }).message ?? '').toLowerCase()
      if (!msg.includes('user rejected')) setTransferMsg('❌ Transfer başarısız.')
    } finally {
      setTransferring(false)
    }
  }

  // Not connected
  if (!isConnected) {
    return (
      <div style={{ textAlign: 'center', padding: '48px 16px', fontFamily: 'system-ui,sans-serif' }}>
        <ShieldOff size={36} style={{ color: '#9c7b62', marginBottom: 12 }} />
        <p style={{ fontSize: 16, fontWeight: 700, color: '#2c1a0e', margin: '0 0 6px' }}>Cüzdanını bağla</p>
        <p style={{ fontSize: 13, color: '#9c7b62', margin: 0 }}>Admin dashboard'a erişmek için cüzdanını bağlamalısın.</p>
      </div>
    )
  }

  // Not admin
  if (!isAdmin) {
    return (
      <div style={{ textAlign: 'center', padding: '48px 16px', fontFamily: 'system-ui,sans-serif' }}>
        <ShieldOff size={36} style={{ color: '#ba2b4c', marginBottom: 12 }} />
        <p style={{ fontSize: 16, fontWeight: 700, color: '#2c1a0e', margin: '0 0 6px' }}>Erişim reddedildi</p>
        <p style={{ fontSize: 13, color: '#9c7b62', margin: '0 0 8px' }}>Bu panel yalnızca uygulama yöneticisine açıktır.</p>
        <span style={{ fontSize: 11, fontFamily: 'monospace', background: 'rgba(186,43,76,0.08)', color: '#ba2b4c', padding: '4px 10px', borderRadius: 8 }}>
          Bağlı: {fmt(address!)}
        </span>
      </div>
    )
  }

  const stats = statsData as [bigint, bigint, bigint] | undefined
  const donors = (donorsData as string[]) ?? []
  const donations = (allDonations as Donation[]) ?? []
  const isLoading = statsLoading || donorsLoading || donationsLoading

  const tabBtn = (id: typeof activeTab, label: string) => (
    <button onClick={() => setActiveTab(id)}
      style={{ padding: '8px 16px', borderRadius: 10, border: 'none', fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'system-ui,sans-serif', background: activeTab === id ? '#2c1a0e' : 'rgba(44,26,14,0.07)', color: activeTab === id ? '#fff' : '#7a5c44' }}>
      {label}
    </button>
  )

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 720, margin: '0 auto', fontFamily: 'system-ui,sans-serif' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <ShieldCheck size={18} style={{ color: '#1a8047' }} />
          <p style={{ fontSize: 15, fontWeight: 800, color: '#2c1a0e', margin: 0 }}>Yönetici Paneli</p>
          <span style={{ fontSize: 10, fontWeight: 700, background: 'rgba(26,128,71,0.12)', color: '#1a8047', padding: '2px 8px', borderRadius: 8 }}>ADMIN</span>
        </div>
        <button onClick={handleRefreshAll} disabled={isLoading}
          style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '7px 12px', borderRadius: 10, background: 'rgba(44,26,14,0.06)', border: '1px solid rgba(44,26,14,0.10)', fontSize: 12, fontWeight: 600, color: '#4a2c1a', cursor: 'pointer' }}>
          {isLoading ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />} Yenile
        </button>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 6 }}>
        {tabBtn('overview', '📊 Genel Bakış')}
        {tabBtn('donors', `👥 Bağışçılar (${donors.length})`)}
        {tabBtn('donations', `☕ Bağışlar (${donations.length})`)}
      </div>

      {/* Overview tab */}
      {activeTab === 'overview' && (
        <>
          {/* Stat cards */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
            <StatCard
              icon={<Users size={18} style={{ color: '#4a2c1a' }} />}
              label="Toplam Bağışçı"
              value={isLoading ? '…' : (stats?.[0] ?? 0n).toString()}
              sub="Benzersiz adres"
            />
            <StatCard
              icon={<Coffee size={18} style={{ color: '#4a2c1a' }} />}
              label="Toplam Bağış"
              value={isLoading ? '…' : (stats?.[1] ?? 0n).toString()}
              sub="İşlem sayısı"
            />
            <StatCard
              icon={<TrendingUp size={18} style={{ color: '#4a2c1a' }} />}
              label="Toplam Tutar"
              value={isLoading ? '…' : `${(stats?.[2] ?? 0n).toString()} USDC`}
              sub="Test USDC"
            />
          </div>

          {/* Admin transfer */}
          <div style={card}>
            <p style={{ fontSize: 13, fontWeight: 700, color: '#2c1a0e', margin: '0 0 12px' }}>Admin Transferi</p>
            <p style={{ fontSize: 12, color: '#7a5c44', margin: '0 0 12px' }}>Admin yetkisini başka bir cüzdana devredebilirsin. Bu işlem geri alınamaz.</p>
            <div style={{ display: 'flex', gap: 8 }}>
              <input value={newAdmin} onChange={e => setNewAdmin(e.target.value)}
                placeholder="Yeni admin adresi (0x…)" spellCheck={false}
                style={{ flex: 1, padding: '10px 12px', borderRadius: 10, border: '1.5px solid rgba(44,26,14,0.14)', fontSize: 12, fontFamily: 'monospace', background: '#faf5f0', color: '#2c1a0e', outline: 'none' }} />
              <button onClick={() => { void handleTransferAdmin() }}
                disabled={transferring || !/^0x[0-9a-fA-F]{40}$/.test(newAdmin.trim())}
                style={{ padding: '10px 16px', borderRadius: 10, background: /^0x[0-9a-fA-F]{40}$/.test(newAdmin.trim()) ? '#ba2b4c' : 'rgba(44,26,14,0.08)', color: /^0x[0-9a-fA-F]{40}$/.test(newAdmin.trim()) ? '#fff' : '#9c7b62', border: 'none', fontSize: 12, fontWeight: 700, cursor: 'pointer', flexShrink: 0 }}>
                {transferring ? <Loader2 size={14} className="animate-spin" /> : 'Transfer Et'}
              </button>
            </div>
            {transferMsg && <p style={{ fontSize: 12, color: '#4a2c1a', margin: '8px 0 0', background: '#faf5f0', padding: '8px 12px', borderRadius: 8 }}>{transferMsg}</p>}
          </div>
        </>
      )}

      {/* Donors tab */}
      {activeTab === 'donors' && (
        <div style={card}>
          <p style={{ fontSize: 13, fontWeight: 700, color: '#2c1a0e', margin: '0 0 12px' }}>Tüm Bağışçılar</p>
          {donorsLoading ? (
            <div style={{ textAlign: 'center', padding: '24px 0' }}><Loader2 size={20} className="animate-spin" style={{ color: '#c49a6c' }} /></div>
          ) : donors.length === 0 ? (
            <p style={{ fontSize: 13, color: '#9c7b62', textAlign: 'center', padding: '24px 0', margin: 0 }}>Henüz bağışçı yok.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {donors.map((d, i) => (
                <DonorRow key={d} rank={i + 1} address={d} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Donations tab */}
      {activeTab === 'donations' && (
        <div style={card}>
          <p style={{ fontSize: 13, fontWeight: 700, color: '#2c1a0e', margin: '0 0 12px' }}>Tüm Bağışlar</p>
          {donationsLoading ? (
            <div style={{ textAlign: 'center', padding: '24px 0' }}><Loader2 size={20} className="animate-spin" style={{ color: '#c49a6c' }} /></div>
          ) : donations.length === 0 ? (
            <p style={{ fontSize: 13, color: '#9c7b62', textAlign: 'center', padding: '24px 0', margin: 0 }}>Henüz bağış kaydı yok.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {[...donations].reverse().map((d, i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: i % 2 === 0 ? '#faf5f0' : '#fff', borderRadius: 10, padding: '10px 14px', border: '1px solid rgba(44,26,14,0.06)' }}>
                  <div>
                    <p style={{ fontSize: 13, fontWeight: 700, color: '#2c1a0e', margin: '0 0 2px' }}>☕ {d.coffeeName}</p>
                    <p style={{ fontSize: 11, color: '#9c7b62', margin: 0 }}>{d.fraction} · {fmtDate(d.timestamp)}</p>
                  </div>
                  <p style={{ fontSize: 14, fontWeight: 800, color: '#2c1a0e', margin: 0 }}>{d.amountUsdc.toString()} <span style={{ fontSize: 11, fontWeight: 600, color: '#7a5c44' }}>USDC</span></p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

    </div>
  )
}

function DonorRow({ rank, address }: { rank: number; address: string }) {

  const { data: profileData } = useReadContract({
    address: CONTRACT,
    abi: coffeeProfileAbi,
    functionName: 'getProfile',
    args: [address as `0x${string}`],
    chainId: CHAIN_ID,
  })

  const profile = profileData as [string, string, string, bigint, bigint] | undefined
  const name = profile?.[0] || ''
  const donationCount = Number(profile?.[3] ?? 0n)
  const totalDonated = Number(profile?.[4] ?? 0n)

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, background: '#faf5f0', borderRadius: 10, padding: '10px 14px' }}>
      <span style={{ fontSize: 11, fontWeight: 800, color: '#9c7b62', width: 20, flexShrink: 0 }}>#{rank}</span>
      <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg,#f5d9a8,#d4884a)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <UserCheck size={14} style={{ color: '#7a4010' }} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ fontSize: 12, fontWeight: 700, color: '#2c1a0e', margin: '0 0 2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {name || fmt(address)}
        </p>
        <p style={{ fontSize: 10, fontFamily: 'monospace', color: '#9c7b62', margin: 0 }}>{fmt(address)}</p>
      </div>
      <div style={{ textAlign: 'right', flexShrink: 0 }}>
        <p style={{ fontSize: 13, fontWeight: 800, color: '#2c1a0e', margin: '0 0 1px' }}>{totalDonated} USDC</p>
        <p style={{ fontSize: 10, color: '#9c7b62', margin: 0 }}>{donationCount} bağış</p>
      </div>
    </div>
  )
}
