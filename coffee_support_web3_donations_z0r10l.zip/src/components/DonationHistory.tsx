import { motion } from 'framer-motion'
import { ExternalLink, Clock } from 'lucide-react'
import { buildTxExplorerUrl } from '@/onchain-facts'
import { TARGET_CHAIN } from '../constants'

export interface DonationRecord {
  id: string
  coffeeName: string
  amount: number
  address: string
  txHash: `0x${string}`
  timestamp: number
  status: 'confirmed' | 'pending' | 'failed'
}

interface DonationHistoryProps {
  records: DonationRecord[]
}

function formatAddress(addr: string) {
  if (!addr || addr.length < 10) return addr
  return `${addr.slice(0, 6)}…${addr.slice(-4)}`
}

function timeAgo(ts: number): string {
  const secs = Math.floor((Date.now() - ts) / 1000)
  if (secs < 60) return 'just now'
  if (secs < 3600) return `${Math.floor(secs / 60)}m ago`
  if (secs < 86400) return `${Math.floor(secs / 3600)}h ago`
  return `${Math.floor(secs / 86400)}d ago`
}

const STATUS_STYLE: Record<DonationRecord['status'], { bg: string; text: string; label: string }> = {
  confirmed: { bg: 'rgba(26,128,71,0.10)', text: 'var(--success)', label: 'Confirmed' },
  pending: { bg: 'rgba(196,154,108,0.15)', text: 'var(--focus)', label: 'Pending' },
  failed: { bg: 'rgba(186,43,76,0.10)', text: 'var(--danger)', label: 'Failed' },
}

export function DonationHistory({ records }: DonationHistoryProps) {
  if (records.length === 0) return null

  return (
    <section>
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-40px' }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="mb-4"
      >
        <h2 className="display text-lg font-bold" style={{ color: 'var(--ink)' }}>
          Recent Coffee Support
        </h2>
        <p className="mt-0.5 text-sm" style={{ color: 'var(--muted)' }}>
          Latest onchain donations in this session
        </p>
      </motion.div>

      <div className="space-y-2">
        {records.map((record, i) => {
          const st = STATUS_STYLE[record.status]
          return (
            <motion.div
              key={record.id}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.35, delay: i * 0.04, ease: [0.22, 1, 0.36, 1] }}
              className="flex items-center justify-between rounded-2xl px-4 py-3.5"
              style={{
                background: 'rgba(255,255,255,0.72)',
                backdropFilter: 'blur(16px)',
                WebkitBackdropFilter: 'blur(16px)',
                border: '1px solid rgba(255,255,255,0.68)',
                boxShadow: '0 2px 12px rgba(44,26,14,0.06)',
              }}
            >
              <div className="flex items-center gap-3">
                <div
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-base"
                  style={{ background: 'rgba(44,26,14,0.06)' }}
                >
                  ☕
                </div>
                <div>
                  <p className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>
                    {record.coffeeName}
                  </p>
                  <div className="mt-0.5 flex items-center gap-2">
                    <span className="mono text-xs" style={{ color: 'var(--subtle)' }}>
                      {formatAddress(record.address)}
                    </span>
                    <span className="text-xs" style={{ color: 'var(--subtle)' }}>·</span>
                    <span className="flex items-center gap-0.5 text-xs" style={{ color: 'var(--subtle)' }}>
                      <Clock size={10} />
                      {timeAgo(record.timestamp)}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex flex-col items-end gap-1.5">
                <span className="display text-sm font-bold tabular-nums" style={{ color: 'var(--accent)' }}>
                  {record.amount} USDC
                </span>
                <div className="flex items-center gap-1.5">
                  <span
                    className="rounded-full px-2 py-0.5 text-xs font-semibold"
                    style={{ background: st.bg, color: st.text }}
                  >
                    {st.label}
                  </span>
                  <a
                    href={buildTxExplorerUrl(TARGET_CHAIN.chainId, record.txHash)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="transition-opacity hover:opacity-70"
                    style={{ color: 'var(--subtle)' }}
                    title="View on explorer"
                  >
                    <ExternalLink size={12} />
                  </a>
                </div>
              </div>
            </motion.div>
          )
        })}
      </div>
    </section>
  )
}
