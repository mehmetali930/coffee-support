import { CoffeeApp } from './components/CoffeeApp'
export default function App() { return <CoffeeApp /> }
